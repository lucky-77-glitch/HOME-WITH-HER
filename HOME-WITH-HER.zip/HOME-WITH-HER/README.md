# HOME WITH HER

Visual novel horor psikologis / dark romance untuk Android (bahasa Indonesia). Game berjalan 100% offline di dalam WebView; tidak ada permission, backend, atau library eksternal.

## Cara membangun APK dari HP
1. Buat repo baru di GitHub (browser HP), lalu unggah **isi** folder ini (bukan folder induknya). Pastikan `.github/workflows/build-apk.yml` ikut terunggah. Opsi "Upload files" di GitHub tidak selalu menyertakan folder tersembunyi; jika `.github` tidak ikut, buat file `.github/workflows/build-apk.yml` lewat tombol "Add file > Create new file" dan tempel isinya.
2. Push ke branch `main`, atau buka tab **Actions > Build APK > Run workflow**.
3. Setelah hijau, buka run tersebut dan unduh artifact **HOME-WITH-HER-debug-apk** (ZIP berisi `app-debug.apk`). Ekstrak, pasang, izinkan "install dari sumber tidak dikenal".
4. APK ini adalah **debug build** untuk pengujian. APK release untuk distribusi memerlukan signing dengan keystore pribadi yang disimpan aman (jangan commit `.jks`/`.keystore`).

Versi yang dipakai: AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7 (via `gradle/actions/setup-gradle`), JDK 17, compileSdk/targetSdk 34, minSdk 24. Belum ada Gradle wrapper; workflow memasang Gradle sendiri.

## Struktur
- `app/src/main/java/com/homewithher/game/MainActivity.kt` — wrapper WebView (tanpa JS bridge, tanpa permission, akses file dimatikan, navigasi di luar aset diblokir, tombol Back diserahkan ke game).
- `app/src/main/assets/` — seluruh game:
  - `js/story.js` registri (karakter, chapter, petunjuk, ending) + `story_a..d.js` isi cerita
  - `js/engine.js` adegan/dialog/pilihan, `state.js`, `save.js`, `settings.js`, `audio.js`, `effects.js`, `portrait.js`, `app.js` (menu & UI)
  - `css/` empat stylesheet; `images/` dan `audio/` kosong (lihat bawah)

## Menambah/mengubah cerita
Adegan didefinisikan dengan `sc('id_adegan', {...})` dan helper `R(...)` Reina, `M(...)` protagonis, `N(...)` narasi, `T(...)` Raka, `B(...)` Bu Hartini, `TH(...)` pikiran. Ekspresi Reina: NORMAL, HAPPY, SHY, FLIRTY, SAD, JEALOUS, ANGRY, EMPTY, UNNATURAL, MONSTER, AUTO (mengikuti Instability). Efek langkah: `fx: 'shake'|'flicker'|'glitch'|'flash'|'jump'`, `sfx: 'door'|'knock'|'step'|'heart'|'hum'|'sting'|'glass'|'phone'|'thunder'|'whisper'|'chime'`. Latar: street, porch, living, bedroom, kitchen, hall, bath, attic, grave, mystery, black. Setelah mengedit, buka game: konsol akan menampilkan tautan adegan yang rusak (`H.validate()`).

## Aset
Semua visual adalah placeholder SVG/CSS buatan sendiri (potret Reina, latar) dan audio disintesis lewat WebAudio. **Belum ada ilustrasi atau musik final.** Ganti nanti dengan aset orisinal: taruh di `images/` dan `audio/`, lalu hubungkan di `portrait.js` / `audio.js`.

## Uji manual di HP
1. Pasang APK, buka: menu judul harus tampil dengan hujan dan Reina.
2. Game Baru, ketik nama, mainkan Prolog sampai pilihan; ketuk layar untuk lanjut.
3. Menu > Simpan Game ke slot 1, keluar paksa dari aplikasi, buka lagi, Muat Game: posisi harus kembali.
4. Pengaturan: volume utama ke 0 harus membisukan semuanya; "Kurangi kedip" mematikan glitch/flash; ubah ukuran teks.
5. Tekan tombol Back Android saat bermain: muncul menu jeda, bukan keluar langsung.
6. Matikan data seluler/Wi-Fi: game tetap berjalan.
