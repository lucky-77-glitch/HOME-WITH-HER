// Audio sintetis (WebAudio): tidak butuh file audio, sepenuhnya offline.
(function () {
  const H = window.HWH;
  let ctx = null, master, musicG, sfxG, rainG, rainSrc, theme = null, themeName = 'none', rainOn = false, noiseBuf = null;

  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain(); musicG = ctx.createGain(); sfxG = ctx.createGain(); rainG = ctx.createGain();
    musicG.connect(master); sfxG.connect(master); rainG.connect(sfxG); master.connect(ctx.destination);
    const len = ctx.sampleRate * 2; noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    A.setVolumes(); return ctx;
  }
  function noise(dur, type, freq, vol, when) {
    const t = ctx.currentTime + (when || 0);
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(sfxG); s.start(t); s.stop(t + dur + 0.05);
  }
  function tone(freq, dur, type, vol, when, endFreq) {
    const t = ctx.currentTime + (when || 0);
    const o = ctx.createOscillator(); o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(sfxG); o.start(t); o.stop(t + dur + 0.05);
  }
  const SFX = {
    door: () => { noise(0.25, 'lowpass', 400, 0.9); tone(70, 0.3, 'sine', 0.9); },
    knock: () => { [0, 0.22, 0.44].forEach((w) => { noise(0.1, 'lowpass', 500, 0.8, w); tone(110, 0.1, 'sine', 0.7, w); }); },
    step: () => { [0, 0.45, 0.9, 1.35].forEach((w) => { noise(0.12, 'lowpass', 300, 0.5, w); }); },
    heart: () => { [0, 0.2, 1, 1.2].forEach((w) => tone(55, 0.18, 'sine', 0.9, w)); },
    hum: () => { tone(60, 3, 'sawtooth', 0.12, 0, 90); tone(61.5, 3, 'sawtooth', 0.12, 0, 91); },
    sting: () => { tone(220, 0.8, 'sawtooth', 0.35, 0, 90); tone(233, 0.8, 'sawtooth', 0.35, 0, 95); noise(0.6, 'highpass', 2500, 0.5); },
    glass: () => { noise(0.5, 'highpass', 5000, 0.7); tone(2400, 0.4, 'triangle', 0.2, 0, 1800); },
    phone: () => { [0, 0.35, 1.2, 1.55].forEach((w) => tone(880, 0.25, 'square', 0.15, w)); },
    thunder: () => { noise(2.2, 'lowpass', 180, 1.0); tone(45, 2, 'sine', 0.8, 0, 30); },
    whisper: () => { noise(1.4, 'bandpass', 2200, 0.25); },
    chime: () => { tone(880, 1.2, 'sine', 0.25); tone(1320, 1.2, 'sine', 0.15, 0.05); }
  };

  const THEMES = {
    calm: { chord: [220, 261.6, 329.6, 392], wave: 'sine', vol: 0.09, cut: 900, lfo: 0.15 },
    tender: { chord: [196, 246.9, 293.7, 392], wave: 'triangle', vol: 0.08, cut: 700, lfo: 0.1 },
    tense: { chord: [110, 116.5, 164.8, 174.6], wave: 'sawtooth', vol: 0.05, cut: 420, lfo: 0.3 },
    horror: { chord: [55, 58.3, 82.4, 87.3, 233], wave: 'sawtooth', vol: 0.07, cut: 600, lfo: 0.6 },
    sad: { chord: [174.6, 207.7, 261.6], wave: 'sine', vol: 0.09, cut: 600, lfo: 0.08 }
  };

  function stopTheme(fade) {
    if (!theme) return;
    const t = theme, now = ctx.currentTime;
    t.g.gain.cancelScheduledValues(now); t.g.gain.setValueAtTime(t.g.gain.value, now); t.g.gain.linearRampToValueAtTime(0.0001, now + (fade || 1.2));
    setTimeout(() => { t.nodes.forEach((n) => { try { n.stop(); } catch (e) { /* sudah berhenti */ } }); }, (fade || 1.2) * 1000 + 100);
    theme = null;
  }

  const A = H.audio = {
    unlock() { ensure(); if (ctx && ctx.state === 'suspended' && H.settings.master > 0) ctx.resume(); },
    setVolumes() {
      if (!ctx) return;
      const s = H.settings, m = s.master / 100;
      master.gain.value = m; musicG.gain.value = (s.music / 100) * 0.9; sfxG.gain.value = (s.sfx / 100) * 0.9;
      if (m <= 0.001) ctx.suspend(); else if (ctx.state === 'suspended') ctx.resume();
    },
    music(name) {
      if (!name) name = 'none';
      if (!ensure() || name === themeName) return;
      themeName = name; stopTheme(1.5);
      const T = THEMES[name]; if (!T) return;
      const g = ctx.createGain(); g.gain.value = 0.0001;
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = T.cut;
      const lfo = ctx.createOscillator(); lfo.frequency.value = T.lfo;
      const lg = ctx.createGain(); lg.gain.value = T.cut * 0.4; lfo.connect(lg); lg.connect(f.frequency);
      f.connect(g); g.connect(musicG);
      const nodes = [lfo];
      T.chord.forEach((fr, i) => {
        const o = ctx.createOscillator(); o.type = T.wave; o.frequency.value = fr; o.detune.value = (i % 2 ? 6 : -6);
        const og = ctx.createGain(); og.gain.value = T.vol; o.connect(og); og.connect(f); o.start(); nodes.push(o);
      });
      lfo.start(); g.gain.linearRampToValueAtTime(1, ctx.currentTime + 2);
      theme = { g, nodes };
    },
    rain(on) {
      if (!ensure()) return;
      if (on === rainOn) return; rainOn = on;
      if (on) {
        rainSrc = ctx.createBufferSource(); rainSrc.buffer = noiseBuf; rainSrc.loop = true;
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2400; f.Q.value = 0.4;
        rainSrc.connect(f); f.connect(rainG); rainG.gain.value = 0.22; rainSrc.start();
      } else if (rainSrc) { try { rainSrc.stop(); } catch (e) { /* ok */ } rainSrc = null; }
    },
    sfx(name, soft) {
      if (!ensure() || !SFX[name]) return;
      if (soft) { const prev = sfxG.gain.value; sfxG.gain.value = prev * 0.4; setTimeout(() => A.setVolumes(), 2600); }
      SFX[name]();
    },
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend(); },
    resume() { if (ctx && H.settings.master > 0) ctx.resume(); }
  };
})();
