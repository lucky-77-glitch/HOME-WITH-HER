(function () {
  const H = window.HWH;
  H.CLAMP = (v) => Math.max(0, Math.min(100, Math.round(v)));
  H.S = null;

  H.newState = function (name) {
    return { v: 1, scene: 'p1', step: 0, ch: 'p', aff: 20, sus: 10, ins: 5,
      f: {}, clues: [], name: name || 'Arka', log: [], picks: [] };
  };

  H.addStats = function (a) {
    if (!a || !H.S) return;
    ['aff', 'sus', 'ins'].forEach((k) => {
      if (typeof a[k] === 'number') H.S[k] = H.CLAMP(H.S[k] + a[k]);
    });
    if (H.onStats) H.onStats();
  };
  H.setFlags = function (list) {
    (list || []).forEach((k) => { H.S.f[k] = 1; });
  };
  H.incFlags = function (list) {
    (list || []).forEach((k) => { H.S.f[k] = (H.S.f[k] || 0) + 1; });
  };
  H.addClue = function (id) {
    if (!H.clues[id]) return;
    if (H.S.clues.indexOf(id) < 0) {
      H.S.clues.push(id);
      H.toast('Petunjuk baru: ' + H.clues[id].title);
    }
  };
  H.hasClue = (id) => H.S.clues.indexOf(id) >= 0;
  H.insLevel = () => (H.S.ins >= 80 ? 3 : H.S.ins >= 60 ? 2 : H.S.ins >= 35 ? 1 : 0);
  H.fill = (t) => String(t).replace(/\{n\}/g, H.S ? H.S.name : 'Arka');
})();
