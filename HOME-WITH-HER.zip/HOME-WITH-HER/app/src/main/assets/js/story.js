// Registri cerita: karakter, chapter, petunjuk, ending, dan helper penulisan adegan.
(function () {
  const H = window.HWH = window.HWH || {};
  H.story = {};
  H.chars = { R: { name: 'Reina' }, T: { name: 'Raka' }, B: { name: 'Bu Hartini' } };

  H.chapterDefs = [
    { id: 'p',  name: 'Prolog — Gadis di Tengah Hujan', kicker: 'PROLOG', start: 'p1' },
    { id: 'c1', name: 'Chapter 1 — Tamu yang Sempurna', kicker: 'CHAPTER 1', start: 'c1_morning' },
    { id: 'c2', name: 'Chapter 2 — Seseorang di Cermin', kicker: 'CHAPTER 2', start: 'c2_bath' },
    { id: 'c3', name: 'Chapter 3 — Tinggallah Sedikit Lebih Lama', kicker: 'CHAPTER 3', start: 'c3_dinner' },
    { id: 'c4', name: 'Chapter 4 — Hal yang Tak Pernah Kau Ceritakan', kicker: 'CHAPTER 4', start: 'c4_knew' },
    { id: 'c5', name: 'Chapter 5 — Wajahnya yang Lain', kicker: 'CHAPTER 5', start: 'c5_video' },
    { id: 'c6', name: 'Chapter 6 — Aturan Rumah', kicker: 'CHAPTER 6', start: 'c6_door' },
    { id: 'c7', name: 'Chapter 7 — Malam Ketika Dia Ingat', kicker: 'CHAPTER 7', start: 'c7_start' },
    { id: 'c8', name: 'Chapter 8 — Cinta Bukan Milik Manusia', kicker: 'CHAPTER 8', start: 'c8_hub' },
    { id: 'c9', name: 'Chapter Akhir — Home With Her', kicker: 'CHAPTER AKHIR', start: 'f_start' }
  ];
  H.chapterDefs.forEach((c) => { c.title = c.name; });
  H.chapterOf = function (sceneId) {
    const s = H.story[sceneId]; if (!s) return null;
    if (s.ch === 'e') return { id: 'e', name: 'Epilog', title: 'Epilog', start: null };
    return H.chapterDefs.find((c) => c.id === s.ch) || null;
  };

  H.clues = {
    shadow: { title: 'Bayangan yang terlambat', text: 'Bayangan Reina di dinding tertinggal setengah detik dari gerakannya.' },
    mirror: { title: 'Pantulan yang salah', text: 'Di cermin, Reina tidak tersenyum — dan wajahnya bukan wajah yang kukenal.' },
    knew:   { title: 'Yang tak pernah kuceritakan', text: 'Reina tahu soal jepit perak dan tujuh tahun itu. Aku tidak pernah bilang pada siapa pun.' },
    photo:  { title: 'Foto keluarga Kurose', text: 'Di loteng: foto Reina Kurose, 15 tahun, di depan rumah ini. Wajahnya sama persis dengan tamuku.' },
    rules:  { title: 'Aturan rumah', text: 'Ia masuk karena diundang. Cermin jujur. Nama & wajahnya pinjaman; bila dikembalikan ia terlepas. Jangan buat ia merasa dilupakan.' },
    origin: { title: 'Asal-usulnya', text: 'Ia bukan manusia. Ia mengambil wajah dan nama gadis yang menyelamatkanku tujuh tahun lalu, dari ingatanku sendiri.' }
  };

  H.endings = {
    true:      { name: 'Namamu Sendiri', cond: 'Ketahui asalnya dan aturan rumah, lalu kembalikan nama pinjamannya dan beri nama baru.', hint: 'Pahami siapa dia, lalu beri dia sesuatu yang bukan pinjaman.', blurb: 'Kamu mengembalikan wajah yang bukan miliknya, dan memberinya nama pertamanya.' },
    love:      { name: 'Tinggal Selamanya', cond: 'Kedekatan tinggi, gangguan rendah, dan kamu sudah memaafkan/menenangkannya.', hint: 'Cintai dia dengan tenang dan jangan biarkan dia terguncang.', blurb: 'Kamu bahagia. Dunia di luar rumah mengecil, dan itu harganya.' },
    obsession: { name: 'Tak Akan Pernah Pergi', cond: 'Gangguan sangat tinggi atau terlalu banyak kebohongan lalu tinggal.', hint: 'Bohong dan biarkan dia goyah, lalu tetap tinggal.', blurb: 'Pintunya tidak pernah dikunci. Kamu hanya tidak pernah lagi ingin membukanya.' },
    escape:    { name: 'Hujan di Kota Lain', cond: 'Curiga cukup tinggi, lalu melarikan diri.', hint: 'Cari tahu cukup banyak, lalu lari.', blurb: 'Kamu selamat. Tapi hujan tidak pernah benar-benar berhenti mengikutimu.' },
    bad:       { name: 'Tamu di Rumahmu Sendiri', cond: 'Tidak memahami ancamannya, lalu tinggal atau lari tanpa tahu apa-apa.', hint: 'Jangan curiga sama sekali.', blurb: 'Kamu tidak pernah paham sampai terlambat. Sekarang rumah itu punya penghuni baru, dan itu bukan kamu.' },
    secret:    { name: 'Rumah Tanpa Hujan', cond: 'Kumpulkan seluruh petunjuk, kunjungi makam, dekat tapi tenang, nyaris tanpa bohong, lalu beri nama baru.', hint: 'Kumpulkan semua petunjuk dan akhiri dengan kasih sayang yang jujur.', blurb: 'Untuk pertama kalinya dalam tujuh tahun, hujan berhenti di atas rumah itu.' }
  };

  H.profiles = [
    { id: 'R', name: 'Reina Kurose', text: 'Perempuan 22 tahun yang menumpang di rumahmu: anggun, menggoda, teliti, mudah cemburu. Ada sesuatu pada senyumnya yang berhenti sepersekian detik terlalu lama.' },
    { id: 'M', name: 'Kamu (protagonis)', text: 'Cowok 21 tahun yang tinggal sendirian di rumah kecil di Jalan Kenanga. Namamu bisa kamu pilih. Ada satu benda di laci yang tidak pernah kamu tunjukkan pada siapa pun.', always: true },
    { id: 'T', name: 'Raka', text: 'Sahabatmu sejak SMP. Cerewet, setia, dan lebih peka daripada kelihatannya. Ia yang pertama menyadari ada yang salah.' },
    { id: 'B', name: 'Bu Hartini', text: 'Tetangga yang sudah puluhan tahun di gang itu. Ia ingat keluarga yang tinggal di rumahmu sebelum kamu, dan memilih diam bertahun-tahun.' }
  ];

  // ---- helper penulisan ----
  const mk = (w) => (t, ex, o) => Object.assign({ w: w, t: t, ex: ex }, o || {});
  H.R = mk('R'); H.M = mk('M'); H.N = mk('N'); H.T = mk('T'); H.B = mk('B'); H.TH = mk('TH');
  H.sc = function (id, o) { o.id = id; if (!o.steps) o.steps = []; H.story[id] = o; return o; };

  // Pemeriksaan tautan statis (target berupa string).
  H.validate = function () {
    const bad = [];
    Object.keys(H.story).forEach((id) => {
      const s = H.story[id];
      if (typeof s.next === 'string' && !H.story[s.next]) bad.push(id + ' -> next ' + s.next);
      (s.choices || []).forEach((c, i) => { if (typeof c.to === 'string' && !H.story[c.to]) bad.push(id + '#' + i + ' -> ' + c.to); });
    });
    return bad;
  };
})();
