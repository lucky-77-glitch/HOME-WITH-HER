// Potret Reina & latar: SVG buatan sendiri (placeholder orisinal, bukan aset berhak cipta).
(function () {
  const H = window.HWH;
  const SKIN = '#e8d6d2', HAIR = '#08050a', IRIS = '#7d2b25', LIP = '#8e1d33';

  const EX = {
    NORMAL:    { eyes: 'open', brow: [0, 0], mouth: 'M133 158 Q150 164 167 158', lip: 1 },
    HAPPY:     { eyes: 'arc', brow: [-2, 0], mouth: 'M129 153 Q150 180 171 153 Q150 164 129 153Z', fill: '#3a0710', blush: .35 },
    SHY:       { eyes: 'side', brow: [-3, -4], mouth: 'M141 160 Q150 164 159 160', blush: .7 },
    FLIRTY:    { eyes: 'lid', brow: [-2, 3], mouth: 'M131 158 Q152 169 172 151', lip: 1.4, blush: .2 },
    SAD:       { eyes: 'sad', brow: [4, -6], mouth: 'M136 166 Q150 155 164 166', tear: 1 },
    JEALOUS:   { eyes: 'narrow', brow: [5, 5], mouth: 'M132 160 Q150 163 168 158', lip: 1 },
    ANGRY:     { eyes: 'narrow', brow: [8, 9], mouth: 'M132 167 Q150 153 168 167', glow: 1 },
    EMPTY:     { eyes: 'dead', brow: [0, 0], mouth: 'M136 161 L164 161', dark: 1 },
    UNNATURAL: { eyes: 'wide', brow: [-4, 0], mouth: 'M116 154 Q150 188 184 154 Q150 168 116 154Z', fill: '#2a0509', tilt: 7 },
    MONSTER:   { monster: true }
  };

  function eyes(kind, x, ins) {
    const iris = (cx, cy, r, c) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + (c || IRIS) + '"/><circle cx="' + cx + '" cy="' + cy + '" r="' + (r * 0.45) + '" fill="#120406"/>';
    const eye = (cx, mode) => {
      const w = '<ellipse cx="' + cx + '" cy="118" rx="14" ry="' + (mode === 'wide' ? 12 : 9) + '" fill="#f3ebe8"/>';
      if (mode === 'arc') return '<path d="M' + (cx - 13) + ' 120 Q' + cx + ' 106 ' + (cx + 13) + ' 120" stroke="' + HAIR + '" stroke-width="3" fill="none" stroke-linecap="round"/>';
      if (mode === 'narrow') return w + iris(cx, 119, 5.5) + '<path d="M' + (cx - 15) + ' 112 L' + (cx + 15) + ' 113 L' + (cx + 15) + ' 116 L' + (cx - 15) + ' 114Z" fill="' + SKIN + '"/>';
      if (mode === 'lid') return w + iris(cx + 1, 119, 6.5) + '<path d="M' + (cx - 15) + ' 108 Q' + cx + ' 111 ' + (cx + 15) + ' 108 L' + (cx + 15) + ' 117 Q' + cx + ' 113 ' + (cx - 15) + ' 117Z" fill="' + SKIN + '"/>';
      if (mode === 'dead') return '<ellipse cx="' + cx + '" cy="118" rx="14" ry="9" fill="#d9ccc8"/><circle cx="' + cx + '" cy="118" r="6.5" fill="#2a0c0c"/>';
      if (mode === 'wide') return w + '<circle cx="' + cx + '" cy="118" r="8" fill="' + IRIS + '"/><circle cx="' + cx + '" cy="118" r="2.2" fill="#000"/>';
      const dx = mode === 'side' ? -4 : 0, dy = mode === 'sad' ? 1.5 : 0;
      return w + iris(cx + dx, 118 + dy, 7) + '<circle cx="' + (cx + dx - 2.5) + '" cy="' + (116 + dy) + '" r="1.7" fill="#fff" opacity=".85"/>' +
        '<path d="M' + (cx - 15) + ' 117 Q' + cx + ' 103 ' + (cx + 15) + ' 117" stroke="' + HAIR + '" stroke-width="3.2" fill="none"/>';
    };
    return eye(126, kind) + eye(174, kind);
  }

  function monster(ins) {
    return '<g>' +
      '<path d="M70 410 Q60 120 150 20 Q240 120 230 410Z" fill="' + HAIR + '"/>' +
      '<path d="M96 70 Q40 200 70 400 M110 60 Q70 240 100 410 M204 60 Q250 240 200 410 M190 70 Q260 200 230 400" stroke="#1a0a12" stroke-width="5" fill="none"/>' +
      '<path d="M128 250 L136 340 L164 340 L172 250Z" fill="#cfc1bd"/>' +
      '<path d="M138 230 L148 270 L152 270 L162 230Z" fill="#c4b4b0"/>' +
      '<ellipse cx="150" cy="130" rx="50" ry="78" fill="#d9ccc8"/>' +
      '<ellipse cx="127" cy="112" rx="17" ry="22" fill="#000"/><ellipse cx="173" cy="112" rx="17" ry="22" fill="#000"/>' +
      '<circle cx="127" cy="112" r="3" fill="#ff2040"/><circle cx="173" cy="112" r="3" fill="#ff2040"/>' +
      '<path d="M98 168 Q150 235 202 168 Q150 190 98 168Z" fill="#14020a" stroke="#14020a" stroke-width="2"/>' +
      '<path d="M104 170 Q150 205 196 170" stroke="#e9dcd8" stroke-width="3" stroke-dasharray="3 4" fill="none"/>' +
      '<path d="M104 172 Q150 214 196 172" stroke="#e9dcd8" stroke-width="2" stroke-dasharray="2 4" fill="none"/>' +
      '<path d="M120 80 Q150 60 180 80" stroke="#08050a" stroke-width="3" fill="none"/>' +
      '</g>';
  }

  H.portrait = function (ex, ins, full) {
    ex = EX[ex] ? ex : 'NORMAL'; const d = EX[ex]; ins = ins || 0;
    const wrapS = full ? '<svg viewBox="0 0 300 420" xmlns="http://www.w3.org/2000/svg" style="background:#000;height:100%">' : '<svg viewBox="0 0 300 420" xmlns="http://www.w3.org/2000/svg">';
    if (d.monster) return wrapS + '<defs><radialGradient id="mg"><stop offset="0" stop-color="#5a0014"/><stop offset="1" stop-color="#000"/></radialGradient></defs><rect width="300" height="420" fill="url(#mg)"/>' + monster(ins) + '</svg>';

    const sh = Math.min(0.55, ins / 160);
    let s = wrapS + '<defs><linearGradient id="dress" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b0b14"/><stop offset="1" stop-color="#07030a"/></linearGradient></defs>';
    s += '<path d="M62 420 Q50 150 150 24 Q250 150 238 420Z" fill="' + HAIR + '"/>';                            // rambut belakang
    s += '<path d="M40 420 Q52 322 112 296 L188 296 Q248 322 260 420Z" fill="url(#dress)"/>';                  // pakaian
    s += '<path d="M118 296 Q150 340 182 296 L172 280 Q150 300 128 280Z" fill="' + SKIN + '"/>';              // dada/leher
    s += '<rect x="136" y="224" width="28" height="64" fill="#dcc9c5"/>';                                     // leher
    s += '<path d="M150 322 L150 332" stroke="' + LIP + '" stroke-width="0"/>';
    s += '<g transform="rotate(' + (d.tilt || 0) + ' 150 200)">';
    s += '<ellipse cx="150" cy="132" rx="49" ry="64" fill="' + SKIN + '"/>';                                  // wajah
    if (d.blush) s += '<ellipse cx="116" cy="142" rx="12" ry="6" fill="#d96a7a" opacity="' + d.blush + '"/><ellipse cx="184" cy="142" rx="12" ry="6" fill="#d96a7a" opacity="' + d.blush + '"/>';
    s += '<ellipse cx="126" cy="122" rx="17" ry="11" fill="#2a0a1c" opacity="' + (sh + (d.dark ? .35 : 0)) + '"/><ellipse cx="174" cy="122" rx="17" ry="11" fill="#2a0a1c" opacity="' + (sh + (d.dark ? .35 : 0)) + '"/>';
    s += eyes(d.eyes, 0, ins);
    if (d.glow) s += '<circle cx="126" cy="119" r="10" fill="#ff1840" opacity=".25"/><circle cx="174" cy="119" r="10" fill="#ff1840" opacity=".25"/>';
    const b = d.brow;                                                                                          // alis
    s += '<path d="M108 ' + (100 + b[0] * 0.5) + ' Q126 ' + (94 - b[1] * 0.3) + ' 142 ' + (100 + b[1] * 0.8) + '" stroke="' + HAIR + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>';
    s += '<path d="M158 ' + (100 + b[1] * 0.8) + ' Q174 ' + (94 - b[1] * 0.3) + ' 192 ' + (100 + b[0] * 0.5) + '" stroke="' + HAIR + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>';
    s += '<path d="M150 128 Q153 144 148 148" stroke="#c9b0ac" stroke-width="2" fill="none"/>';              // hidung
    const lw = d.lip ? 4.6 * d.lip : 3.6;
    s += '<path d="' + d.mouth + '" stroke="' + LIP + '" stroke-width="' + lw + '" fill="' + (d.fill || 'none') + '" stroke-linecap="round" stroke-linejoin="round"/>';
    if (ins >= 75 && ex !== 'UNNATURAL') s += '<path d="M127 156 Q150 172 173 156" stroke="#3a0710" stroke-width="1.5" fill="none" opacity=".55"/>';   // senyum "menempel"
    if (d.tear) s += '<path d="M114 128 Q111 142 114 150" stroke="#b9c9e8" stroke-width="2.4" fill="none" opacity=".8"/><path d="M186 128 Q189 142 186 150" stroke="#b9c9e8" stroke-width="2.4" fill="none" opacity=".8"/>';
    s += '<path d="M101 100 Q150 52 199 100 Q190 70 150 62 Q110 70 101 100Z" fill="' + HAIR + '"/>';           // poni
    s += '<path d="M104 96 Q112 140 100 176 M196 96 Q188 140 200 176 M138 66 Q132 92 120 108 M162 66 Q168 92 182 108" stroke="' + HAIR + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
    s += '</g></svg>';
    return s;
  };

  // ---------- Latar ----------
  const BG = {
    street:  { a: '#0b0d1c', b: '#06060d', g: [300, 180, 150, '#3a4a7a'], s: '<rect x="0" y="560" width="400" height="240" fill="#05050a"/><rect x="180" y="150" width="10" height="420" fill="#14141f"/><ellipse cx="185" cy="148" rx="26" ry="9" fill="#3b3f58"/><path d="M60 560 L340 560 L400 800 L0 800Z" fill="#0e0f1b"/>' },
    porch:   { a: '#100912', b: '#050308', g: [200, 260, 170, '#c87c3c'], s: '<rect x="90" y="230" width="220" height="400" fill="#1b0e12"/><rect x="130" y="280" width="140" height="350" fill="#2b1514"/><circle cx="250" cy="470" r="6" fill="#e0a860"/><rect x="0" y="620" width="400" height="180" fill="#07050a"/>' },
    living:  { a: '#2a1420', b: '#0d060b', g: [90, 330, 190, '#ffb870'], s: '<rect x="0" y="600" width="400" height="200" fill="#12090d"/><rect x="40" y="470" width="230" height="110" rx="14" fill="#2a111c"/><rect x="250" y="190" width="120" height="210" fill="#0a1022"/><path d="M270 200 L270 390 M310 200 L310 390 M350 200 L350 390" stroke="#4a5a8a" stroke-width="3"/><rect x="60" y="360" width="22" height="110" fill="#3a2018"/><ellipse cx="71" cy="352" rx="24" ry="14" fill="#ffd9a0"/>' },
    bedroom: { a: '#1a1024', b: '#07040b', g: [330, 220, 170, '#7a5aa8'], s: '<rect x="0" y="620" width="400" height="180" fill="#0d070f"/><rect x="40" y="470" width="260" height="130" rx="10" fill="#2a1630"/><rect x="40" y="430" width="260" height="60" rx="10" fill="#3a2244"/><rect x="290" y="260" width="90" height="140" fill="#0a1022"/>' },
    kitchen: { a: '#201317', b: '#0a0608', g: [200, 140, 200, '#e8dcc0'], s: '<rect x="0" y="560" width="400" height="240" fill="#100a0c"/><rect x="20" y="420" width="360" height="26" fill="#2a1d20"/><rect x="20" y="446" width="360" height="130" fill="#1a1013"/><rect x="40" y="230" width="90" height="130" fill="#241619"/><rect x="270" y="230" width="90" height="130" fill="#241619"/><rect x="170" y="180" width="60" height="6" fill="#d9cdb0"/>' },
    hall:    { a: '#0f0a14', b: '#030204', g: [200, 300, 90, '#6a2030'], s: '<path d="M0 0 L120 200 L120 600 L0 800Z" fill="#0a0610"/><path d="M400 0 L280 200 L280 600 L400 800Z" fill="#0a0610"/><rect x="120" y="200" width="160" height="400" fill="#06030a"/><rect x="168" y="300" width="64" height="300" fill="#12080e"/>' },
    bath:    { a: '#152026', b: '#060a0c', g: [200, 260, 150, '#9fd0d8'], s: '<rect x="0" y="600" width="400" height="200" fill="#0c1316"/><rect x="95" y="170" width="210" height="290" rx="8" fill="#0b1013" stroke="#8aa8b0" stroke-width="5"/><rect x="105" y="180" width="190" height="270" fill="#1d2d33"/><rect x="60" y="480" width="280" height="40" rx="8" fill="#d8e4e6" opacity=".25"/>' },
    attic:   { a: '#1a140d', b: '#060403', g: [320, 200, 140, '#d8b070'], s: '<path d="M0 120 L200 0 L400 120 L400 800 L0 800Z" fill="#100b07"/><rect x="60" y="500" width="120" height="90" fill="#2a1c10"/><rect x="220" y="540" width="100" height="70" fill="#251a0e"/><circle cx="320" cy="200" r="38" fill="#2a2a1a"/>' },
    grave:   { a: '#101420', b: '#05060b', g: [200, 120, 220, '#8a9ac8'], s: '<rect x="0" y="620" width="400" height="180" fill="#07090e"/><rect x="150" y="430" width="90" height="190" rx="40" fill="#252a38"/><rect x="170" y="470" width="50" height="4" fill="#0a0c12"/><rect x="170" y="486" width="36" height="4" fill="#0a0c12"/><path d="M40 620 L40 540 M60 620 L60 560 M330 620 L330 520" stroke="#161a24" stroke-width="12"/>' },
    mystery: { a: '#1c0612', b: '#000', g: [200, 400, 260, '#5a0a24'], s: '<path d="M0 800 L200 380 L400 800Z" fill="#0b0207" opacity=".7"/><circle cx="200" cy="300" r="60" fill="#000"/>' },
    black:   { a: '#000', b: '#000', g: [0, 0, 0, '#000'], s: '' }
  };
  H.bg = function (name) {
    const d = BG[name] || BG.black, g = d.g, id = 'bg' + name;
    return '<svg viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="' + id + 'l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + d.a + '"/><stop offset="1" stop-color="' + d.b + '"/></linearGradient>' +
      '<radialGradient id="' + id + 'r"><stop offset="0" stop-color="' + g[3] + '" stop-opacity=".55"/><stop offset="1" stop-color="' + g[3] + '" stop-opacity="0"/></radialGradient></defs>' +
      '<rect width="400" height="800" fill="url(#' + id + 'l)"/><circle cx="' + g[0] + '" cy="' + g[1] + '" r="' + g[2] + '" fill="url(#' + id + 'r)"/>' + d.s + '</svg>';
  };
  H.bgNames = Object.keys(BG);
})();
