(function () {
  const H = window.HWH, $ = (id) => document.getElementById(id), esc = (s) => H.esc(s);
  let screenBack = null, titleOn = true;
  const U = H.ui = {};

  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
  function mbtn(label, fn, dis) { const b = el('button', 'mbtn'); b.textContent = label; if (dis) b.disabled = true; else b.onclick = fn; return b; }

  // ---------- modal ----------
  function modal(msg, buttons, input) {
    const m = $('modal'); m.innerHTML = ''; const box = el('div', 'mbox'); const p = el('p'); p.textContent = msg; box.appendChild(p);
    let inp = null; if (input) { inp = el('input', 'input'); inp.maxLength = 12; inp.value = input; inp.autocomplete = 'off'; box.appendChild(inp); }
    const row = el('div', 'row');
    buttons.forEach((b) => { const x = el('button', b.pri ? 'pri' : ''); x.textContent = b.label; x.onclick = () => { closeModal(); if (b.fn) b.fn(inp ? inp.value : null); }; row.appendChild(x); });
    box.appendChild(row); m.appendChild(box); m.classList.remove('hidden');
  }
  function closeModal() { $('modal').classList.add('hidden'); $('modal').innerHTML = ''; }
  const confirmBox = (msg, yes, label) => modal(msg, [{ label: 'Batal' }, { label: label || 'Ya', pri: 1, fn: yes }]);

  // ---------- layar umum ----------
  function screen(title, build, back) {
    const s = $('screen'); s.innerHTML = '';
    const sh = el('div', 'sh'); sh.appendChild(el('h2', '', esc(title)));
    const cb = el('button'); cb.textContent = 'Tutup'; cb.onclick = () => U.closeScreen(); sh.appendChild(cb); s.appendChild(sh);
    const body = el('div', 'sbody'); s.appendChild(body); build(body);
    screenBack = back || null; s.classList.remove('hidden'); H.engine.stopSkip();
  }
  U.closeScreen = function () { $('screen').classList.add('hidden'); $('screen').innerHTML = ''; const b = screenBack; screenBack = null; if (b) b(); };

  // ---------- judul ----------
  U.showTitle = function () {
    H.engine.stop(); titleOn = true; H.S = null;
    $('bg').innerHTML = H.bg('porch'); H.fx.rain(true); H.audio.music('tender'); H.fx.setIns();
    $('portrait').classList.remove('off'); $('portrait').innerHTML = H.portrait('SHY', 0); $('shadowfig').innerHTML = '';
    const t = $('title'); t.innerHTML = '<h1>HOME<br>WITH HER</h1><div class="sub">Dia tidak pernah bilang dari mana dia datang.</div>';
    const any = H.hasAnySave(), chs = Object.keys(H.meta.chapters).length > 1;
    t.appendChild(mbtn('Lanjutkan', () => { const d = H.latestSave(); if (d) U.loadData(d); }, !any));
    t.appendChild(mbtn('Game Baru', U.newGame));
    t.appendChild(mbtn('Muat Game', () => U.slots('load', U.showTitleKeep), !any));
    t.appendChild(mbtn('Pilih Chapter', U.chapters, !chs));
    t.appendChild(mbtn('Galeri Ending', U.gallery));
    t.appendChild(mbtn('Extras · Profil Karakter', U.extras));
    t.appendChild(mbtn('Pengaturan', () => U.settings(U.showTitleKeep)));
    t.appendChild(mbtn('Kredit', U.credits));
    t.appendChild(mbtn('Keluar', () => modal('Untuk keluar, tekan tombol Kembali Android di layar judul.', [{ label: 'Mengerti', pri: 1 }])));
    t.classList.remove('hidden'); $('screen').classList.add('hidden'); $('modal').classList.add('hidden');
  };
  U.showTitleKeep = function () { if (titleOn) { $('title').classList.remove('hidden'); } };

  U.newGame = function () {
    modal('Siapa namamu?', [{ label: 'Batal' }, { label: 'Mulai', pri: 1, fn: (v) => {
      const n = (v || '').replace(/[<>&"]/g, '').trim() || 'Arka'; titleOn = false; U.begin(H.newState(n.slice(0, 12)));
    } }], 'Arka');
  };
  U.begin = function (st) { titleOn = false; H.audio.unlock(); $('title').classList.add('hidden'); H.engine.begin(st); };
  U.loadData = function (d) { U.begin(H.stateFromSave(d)); };

  // ---------- slot ----------
  U.slots = function (mode, back) {
    screen(mode === 'save' ? 'Simpan Game' : 'Muat Game', (b) => {
      H.slots.forEach((slot) => {
        const r = H.readSlot(slot), c = el('div', 'card' + (r.data ? '' : ' locked'));
        const name = slot === 'auto' ? 'Auto-save' : 'Slot ' + slot;
        if (r.data) c.innerHTML = '<h3>' + name + ' — ' + esc(r.data.chTitle) + '</h3><p>' + H.fmtTime(r.data.t) + ' · ' + esc(r.data.name) + '<br>Kedekatan ' + r.data.aff + ' · Curiga ' + r.data.sus + ' · Gangguan ' + r.data.ins + '</p>';
        else if (r.error) c.innerHTML = '<h3>' + name + ' — data bermasalah</h3><p>' + esc(r.error) + ' Save tidak dihapus; kamu bisa menimpanya atau menghapusnya manual.</p>';
        else c.innerHTML = '<h3>' + name + '</h3><p>Kosong</p>';
        const row = el('div', 'row');
        if (mode === 'save' && slot !== 'auto') { const x = el('button'); x.textContent = 'Simpan'; x.onclick = () => { const go = () => { H.writeSlot(slot); H.toast('Tersimpan di slot ' + slot); U.slots('save', back); }; r.data || r.error ? confirmBox('Timpa slot ' + slot + '?', go, 'Timpa') : go(); }; row.appendChild(x); }
        if (mode === 'load' && r.data) { const x = el('button'); x.textContent = 'Muat'; x.onclick = () => { screenBack = null; $('screen').classList.add('hidden'); U.loadData(r.data); }; row.appendChild(x); }
        if ((r.data || r.error) && slot !== 'auto') { const x = el('button'); x.textContent = 'Hapus'; x.onclick = () => confirmBox('Hapus slot ' + slot + '? Tidak bisa dibatalkan.', () => { H.deleteSlot(slot); U.slots(mode, back); }, 'Hapus'); row.appendChild(x); }
        if (row.children.length) c.appendChild(row); b.appendChild(c);
      });
    }, back);
  };

  // ---------- chapter ----------
  U.chapters = function () {
    screen('Pilih Chapter', (b) => {
      H.chapterDefs.forEach((ch) => {
        const snap = H.meta.chapters[ch.id], c = el('div', 'card' + (snap ? '' : ' locked'));
        c.innerHTML = '<h3>' + esc(ch.name) + '</h3><p>' + (snap ? 'Mulai dari awal chapter dengan status saat pertama kali tiba di sini.' : 'Belum terbuka.') + '</p>';
        if (snap) { const row = el('div', 'row'), x = el('button'); x.textContent = 'Main'; x.onclick = () => { screenBack = null; $('screen').classList.add('hidden'); const st = JSON.parse(JSON.stringify(snap)); st.scene = ch.start; st.step = 0; st.applied = false; U.begin(st); }; row.appendChild(x); c.appendChild(row); }
        b.appendChild(c);
      });
    }, U.showTitleKeep);
  };

  // ---------- galeri ----------
  U.gallery = function () {
    screen('Galeri Ending', (b) => {
      const n = Object.keys(H.endings).filter((k) => H.meta.endings[k]).length;
      b.appendChild(el('p', '', '<span style="color:#a99aa0;font-size:13px">Terbuka ' + n + ' / ' + Object.keys(H.endings).length + '</span>'));
      Object.keys(H.endings).forEach((k) => {
        const e = H.endings[k], got = H.meta.endings[k], c = el('div', 'card' + (got ? '' : ' locked'));
        c.innerHTML = got ? '<h3>' + esc(e.name) + '</h3><p>' + esc(e.cond) + '<br><i>' + esc(e.blurb) + '</i></p>' : '<h3>???</h3><p>Petunjuk: ' + esc(e.hint) + '</p>';
        b.appendChild(c);
      });
    }, U.showTitleKeep);
  };
  U.ending = function (id) {
    const e = H.endings[id]; H.unlockEnding(id); H.engine.stopSkip();
    H.autosave(); $('dialog').classList.add('hidden'); $('choices').classList.add('hidden');
    const s = $('screen'); s.innerHTML = '<div style="margin:auto;text-align:center;padding:20px;font-family:Georgia,serif"><div style="color:#a99aa0;font-size:12px;letter-spacing:.2em">ENDING</div><h2 style="font-size:28px;font-weight:400;margin:12px 0">' + esc(e.name) + '</h2><p style="color:#cbbcc1;font-size:15px;line-height:1.6">' + esc(e.blurb) + '</p></div>';
    const row = el('div'); row.appendChild(mbtn('Galeri Ending', () => { screenBack = null; U.gallery(); screenBack = () => U.showTitle(); }));
    row.appendChild(mbtn('Menu Utama', () => { $('screen').classList.add('hidden'); U.showTitle(); })); s.appendChild(row);
    screenBack = null; s.classList.remove('hidden');
  };

  // ---------- extras ----------
  U.extras = function () {
    screen('Extras · Profil Karakter', (b) => {
      H.profiles.forEach((p) => {
        const seen = p.always || H.meta.chars[p.id], c = el('div', 'card' + (seen ? '' : ' locked'));
        c.innerHTML = seen ? '<h3>' + esc(p.name) + '</h3><p>' + esc(p.text) + '</p>' : '<h3>???</h3><p>Belum bertemu.</p>';
        b.appendChild(c);
      });
    }, U.showTitleKeep);
  };

  // ---------- kredit ----------
  U.credits = function () {
    screen('Kredit', (b) => { b.appendChild(el('div', 'card', '<h3>HOME WITH HER</h3><p>Cerita, karakter, kode, dan seluruh visual placeholder: orisinal untuk proyek ini. Suara dibuat secara sintetis lewat WebAudio. Terinspirasi secara suasana oleh genre horor interaktif; tidak ada aset, dialog, atau kode dari game lain.<br><br>Versi 1.0.0</p>')); }, U.showTitleKeep);
  };

  // ---------- pengaturan ----------
  U.settings = function (back) {
    screen('Pengaturan', (b) => {
      const S = H.settings, upd = () => { H.saveSettings(); H.applySettings(); H.engine.syncBtns(); };
      const range = (label, key, min, max, step) => { const d = el('div', 'set', '<span>' + label + '</span>'), i = el('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step || 1; i.value = S[key]; i.oninput = () => { S[key] = Number(i.value); upd(); }; d.appendChild(i); b.appendChild(d); };
      const check = (label, key) => { const d = el('div', 'set', '<span>' + label + '</span>'), i = el('input'); i.type = 'checkbox'; i.checked = !!S[key]; i.onchange = () => { S[key] = i.checked; upd(); }; d.appendChild(i); b.appendChild(d); };
      range('Volume utama', 'master', 0, 100); range('Volume musik', 'music', 0, 100); range('Volume efek suara', 'sfx', 0, 100);
      range('Kecepatan teks (kanan = instan)', 'textSpeed', 1, 5); range('Ukuran teks', 'fontSize', 14, 24);
      check('Auto-advance dialog', 'auto'); check('Lewati hanya teks yang sudah dibaca', 'skipRead');
      check('Kurangi kedip & glitch', 'noflash'); check('Jumpscare aktif', 'jump'); check('Kurangi intensitas jumpscare', 'softjump'); check('Tampilkan meter status', 'meters');
      const d = el('div', 'set', '<span>Kualitas efek hujan</span>'), sel = el('select', '', '<option value="low">Rendah</option><option value="mid">Sedang</option><option value="high">Tinggi</option>');
      sel.value = S.fxq; sel.onchange = () => { S.fxq = sel.value; upd(); }; d.appendChild(sel); b.appendChild(d);
      b.appendChild(el('div', 'set', '<span>Bahasa</span><span style="color:#a99aa0">Indonesia</span>'));
      const r = mbtn('Reset pengaturan', () => confirmBox('Kembalikan semua pengaturan ke bawaan?', () => { H.resetSettings(); U.settings(back); }, 'Reset')); r.style.marginTop = '14px'; b.appendChild(r);
      const w = mbtn('Hapus SEMUA data (save, ending, chapter)', () => confirmBox('Hapus semua save, ending, dan chapter yang terbuka? Tidak bisa dibatalkan.', () => confirmBox('Yakin sekali? Ini permanen.', () => { H.wipeAll(); H.toast('Data dihapus'); U.settings(back); }, 'Hapus permanen'), 'Lanjut'));
      b.appendChild(w);
    }, back);
  };

  // ---------- jurnal & riwayat ----------
  U.journal = function () {
    screen('Jurnal', (b) => {
      const S = H.S, keys = Object.keys(H.clues);
      b.appendChild(el('p', '', '<span style="color:#a99aa0;font-size:13px">Petunjuk ditemukan: ' + S.clues.length + ' / ' + keys.length + '</span>'));
      keys.forEach((k) => { const has = S.clues.indexOf(k) >= 0, c = el('div', 'card' + (has ? '' : ' locked')); c.innerHTML = has ? '<h3>' + esc(H.clues[k].title) + '</h3><p>' + esc(H.clues[k].text) + '</p>' : '<h3>???</h3><p>Belum ditemukan.</p>'; b.appendChild(c); });
      const feel = (S.aff >= 60 ? 'Dia terasa dekat — terlalu dekat.' : S.aff >= 35 ? 'Ada kehangatan di antara kalian.' : 'Dia masih terasa seperti orang asing.') + ' ' + (S.ins >= 70 ? 'Rumah terasa menahan napas.' : S.ins >= 35 ? 'Ada yang tidak beres.' : 'Rumah terasa tenang.');
      b.appendChild(el('div', 'card', '<h3>Catatan pribadi</h3><p>' + esc(feel) + '</p>'));
    });
  };
  U.log = function () {
    screen('Riwayat Dialog', (b) => { H.S.log.slice(-60).forEach((l) => { const d = el('div', 'logline'); if (l.w) d.innerHTML = '<b>' + esc(l.w) + '</b>'; d.appendChild(document.createTextNode(l.t)); b.appendChild(d); }); setTimeout(() => { b.scrollTop = b.scrollHeight; }, 20); });
  };

  // ---------- menu jeda ----------
  U.pause = function () {
    H.engine.stopSkip(); const s = $('screen'); s.innerHTML = ''; const sh = el('div', 'sh'); sh.appendChild(el('h2', '', 'Jeda')); s.appendChild(sh);
    const body = el('div', 'sbody'); s.appendChild(body);
    body.appendChild(mbtn('Lanjutkan', () => U.closeScreen()));
    body.appendChild(mbtn('Simpan Game', () => U.slots('save', U.pause)));
    body.appendChild(mbtn('Muat Game', () => U.slots('load', U.pause), !H.hasAnySave()));
    body.appendChild(mbtn('Pengaturan', () => U.settings(U.pause)));
    body.appendChild(mbtn('Kembali ke Menu Utama', () => confirmBox('Kembali ke menu utama? Progres sejak titik simpan terakhir (auto-save di awal adegan) tidak tersimpan.', () => { U.closeScreen(); U.showTitle(); }, 'Ke menu')));
    screenBack = null; s.classList.remove('hidden');
  };

  // ---------- tombol Android Back ----------
  window.hwhBack = function () {
    if (!$('modal').classList.contains('hidden')) { closeModal(); return true; }
    if (!$('screen').classList.contains('hidden')) { if (H.engine.active && !screenBack && $('screen').querySelector('.mbtn')) { U.closeScreen(); return true; } U.closeScreen(); return true; }
    if (H.engine.active) { U.pause(); return true; }
    if (!$('title').classList.contains('hidden')) return false;
    return false;
  };
  window.hwhPause = function () { H.audio.suspend(); if (H.engine.active) H.autosave(); H.saveMeta(); };
  window.hwhResume = function () { H.audio.resume(); };

  // ---------- init ----------
  document.addEventListener('DOMContentLoaded', () => {
    H.applySettings(); H.fx.init();
    const unlock = () => { H.audio.unlock(); };
    document.addEventListener('touchstart', unlock, { passive: true }); document.addEventListener('click', unlock);
    $('dialog').addEventListener('click', () => H.engine.advance());
    $('stage').addEventListener('click', () => H.engine.advance());
    $('btnMenu').onclick = U.pause; $('btnLog').onclick = U.log; $('btnJournal').onclick = U.journal;
    $('btnSkip').onclick = () => H.engine.toggleSkip(); $('btnAuto').onclick = () => H.engine.toggleAuto();
    window.addEventListener('error', (e) => { console.error('HWH error:', e.message); });
    // validasi tautan adegan saat start (hanya log)
    const bad = H.validate ? H.validate() : []; if (bad.length) console.error('Tautan adegan rusak:', bad);
    U.showTitle();
  });
})();
