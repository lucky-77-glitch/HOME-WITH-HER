(function () {
  const H = window.HWH, $ = (id) => document.getElementById(id);
  let typeTimer = null, autoTimer = null, typing = false, fullText = '', skipping = false, locked = false, rei = false;
  const E = H.engine = { active: false };

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  H.esc = esc;

  function setPortrait(ex) {
    const S = H.S;
    if (ex === 'AUTO' || !ex) ex = (ex === 'AUTO' && S.ins >= 75) ? 'UNNATURAL' : 'NORMAL';
    const svg = H.portrait(ex, S.ins);
    $('portrait').innerHTML = svg; $('shadowfig').innerHTML = svg; E.ex = ex;
  }
  function showPortrait(on) {
    $('portrait').classList.toggle('off', !on); $('shadowfig').style.display = on ? '' : 'none';
  }
  H.refreshMeters = function () {
    const m = $('meters'); if (!H.settings.meters || !E.active) { m.classList.add('hidden'); return; }
    const S = H.S, row = (l, v, c) => '<div class="meter">' + l + '<i><b style="width:' + v + '%;background:' + c + '"></b></i></div>';
    m.innerHTML = row('Kedekatan', S.aff, '#e07a96') + row('Curiga', S.sus, '#e8c36a') + row('Gangguan', S.ins, '#a33cff');
    m.classList.remove('hidden');
  };
  H.onStats = function () { H.refreshMeters(); H.fx.setIns(); };

  E.begin = function (state) {
    H.S = state; E.active = true; skipping = false; locked = false; E.syncBtns();
    ['title', 'screen', 'modal'].forEach((i) => $(i).classList.add('hidden'));
    ['hud', 'dialog'].forEach((i) => $(i).classList.remove('hidden'));
    $('choices').classList.add('hidden'); H.fx.setIns(); H.refreshMeters(); E.pk = null;
    E.enter(state.scene, state.step, true);
  };
  E.stop = function () {
    E.active = false; clearTimers();
    ['hud', 'dialog', 'choices', 'meters'].forEach((i) => $(i).classList.add('hidden'));
    document.body.classList.remove('ins1', 'ins2', 'ins3');
  };
  function clearTimers() { clearInterval(typeTimer); clearTimeout(autoTimer); typing = false; }

  E.enter = function (id, step, loading) {
    const sc = H.story[id], S = H.S;
    if (!sc) { H.toast('Adegan tidak ditemukan: ' + id); return; }
    const newCh = S.ch !== sc.ch;
    S.scene = id; S.step = step || 0; S.ch = sc.ch;
    $('bg').innerHTML = H.bg(sc.bg); H.fx.rain(sc.rain); H.audio.music(sc.mus || 'calm');
    rei = !!sc.rei; showPortrait(rei); E.ex = 'NORMAL'; E.pk = null;
    const ch = H.chapterOf(id); $('chapterTag').textContent = ch ? ch.title : '';
    const isStart = !loading && S.step === 0 && ch && ch.start === id;
    if (isStart) H.unlockChapter(ch.id, JSON.parse(JSON.stringify(Object.assign({}, S, { step: 0, applied: false, log: [] }))));
    if (!loading && S.step === 0) { S.applied = false; H.autosave(); }
    const go = () => E.render(loading && S.applied);
    if (isStart && ch.id !== 'p') {
      const f = $('fade'); f.innerHTML = '<div style="text-align:center;padding:30px;font-family:Georgia,serif"><div style="font-size:13px;color:#a99aa0;letter-spacing:.2em">' + esc(ch.kicker || '') + '</div><div style="font-size:26px;margin-top:10px">' + esc(ch.name) + '</div></div>';
      f.style.display = 'flex'; f.style.alignItems = 'center'; f.style.justifyContent = 'center';
      locked = true; H.fx.fade(true, 400);
      setTimeout(() => { H.fx.fade(false, 800); f.innerHTML = ''; f.style.display = ''; locked = false; go(); }, 2000);
    } else go();
  };

  function applyStep(st) {
    if (st.add) H.addStats(st.add);
    if (st.flag) H.setFlags([].concat(st.flag));
    if (st.inc) H.incFlags([].concat(st.inc));
    if (st.clue) H.addClue(st.clue);
  }

  E.render = function (quiet) {
    clearTimers(); const S = H.S, sc = H.story[S.scene];
    let i = S.step;
    while (i < sc.steps.length && sc.steps[i].cond && !sc.steps[i].cond(S)) i++;
    if (i >= sc.steps.length) return after(sc);
    S.step = i; const st = sc.steps[i];
    if (!quiet) applyStep(st);
    S.applied = true;
    // visual
    if (st.bg) { $('bg').innerHTML = H.bg(st.bg); }
    if (st.mus) H.audio.music(st.mus);
    if (st.rain !== undefined) H.fx.rain(st.rain);
    if (st.hide) showPortrait(false); else if (rei) showPortrait(true);
    if (rei) { const want = st.ex || E.ex || 'NORMAL', key = want + ':' + H.insLevel(); if (key !== E.pk) { E.pk = key; setPortrait(want); } }
    H.fx.setIns();
    if (!quiet) {
      if (st.sfx) H.audio.sfx(st.sfx);
      if (st.fx === 'jump') H.fx.jumpscare(); else if (st.fx && H.fx[st.fx]) H.fx[st.fx]();
    }
    // teks
    let w = st.w, who = '', cls = '';
    if (w === 'N') cls = 'nar'; else if (w === 'TH') { cls = 'thought'; } else if (w === 'M') who = S.name; else who = (H.chars[w] || {}).name || '';
    if (w && w !== 'N' && w !== 'TH') { H.meta.chars[w] = 1; }
    let text = H.fill(typeof st.t === 'function' ? st.t(S) : st.t);
    if (w === 'R' && S.ins >= 70 && Math.random() < 0.35) { const ws = text.split(' '); if (ws.length > 3) { const k = ws[ws.length - 1]; text += ' ' + k.replace(/[.!?…]+$/, '') + '…'; } }
    $('speaker').textContent = who; $('text').className = cls; $('text').textContent = '';
    $('more').style.display = 'none'; $('dialog').classList.remove('hidden'); $('choices').classList.add('hidden');
    if (!quiet || true) S.log.push({ w: who, t: text }); if (S.log.length > 80) S.log.shift();
    const key = S.scene + ':' + S.step, seen = !!H.meta.seen[key];
    if (!seen) { H.meta.seen[key] = 1; }
    fullText = text;
    const cps = H.CPS[H.settings.textSpeed];
    if (skipping && seen && H.settings.skipRead) { $('text').textContent = text; typing = false; skipTimer(); return; }
    if (skipping) { skipping = false; E.syncBtns(); H.toast('Skip berhenti: teks baru'); }
    if (!cps) { $('text').textContent = text; done(); return; }
    typing = true; let n = 0, t0 = performance.now();
    typeTimer = setInterval(() => {
      n = Math.min(text.length, Math.floor((performance.now() - t0) / 1000 * cps));
      $('text').textContent = text.slice(0, n);
      if (n >= text.length) { clearInterval(typeTimer); typing = false; done(); }
    }, 30);
  };
  function skipTimer() { autoTimer = setTimeout(() => E.advance(true), 45); }
  function done() {
    typing = false; $('text').textContent = fullText; $('more').style.display = '';
    if (H.settings.auto && !skipping) autoTimer = setTimeout(() => E.advance(true), 1300 + fullText.length * 40);
  }

  E.advance = function (fromTimer) {
    if (!E.active || locked || !$('choices').classList.contains('hidden')) return;
    if (!$('screen').classList.contains('hidden') || !$('modal').classList.contains('hidden')) return;
    if (typing) { clearInterval(typeTimer); done(); H.saveMeta(); return; }
    if (!fromTimer) clearTimeout(autoTimer);
    H.S.step++; E.render(false);
  };

  function after(sc) {
    const S = H.S; H.saveMeta();
    const list = (sc.choices || []).map((c, idx) => ({ c, idx })).filter((o) => !(o.c.hide && o.c.hide(S)));
    if (sc.end) { H.ui.ending(sc.end); return; }
    if (list.length) {
      skipping = false; E.syncBtns();
      const box = $('choices'); box.innerHTML = '';
      if (sc.q) { const d = document.createElement('div'); d.className = 'cap'; d.textContent = H.fill(sc.q); box.appendChild(d); }
      list.forEach((o) => {
        const c = o.c, ok = !c.req || c.req(S), b = document.createElement('button');
        b.className = 'choice' + (ok ? '' : ' locked'); b.textContent = H.fill(c.t);
        if (!ok) { const sm = document.createElement('small'); sm.textContent = c.reqText || 'Belum tersedia.'; b.appendChild(sm); }
        b.onclick = () => { if (!ok) { H.toast(c.reqText || 'Belum tersedia.'); return; } pick(sc, c, o.idx); };
        box.appendChild(b);
      });
      $('dialog').classList.add('hidden'); box.classList.remove('hidden'); box.scrollTop = 0;
      return;
    }
    if (sc.next) { const n = typeof sc.next === 'function' ? sc.next(S) : sc.next; E.enter(n, 0, false); return; }
    H.toast('Adegan buntu: ' + sc.id);
  }
  function pick(sc, c, idx) {
    if (locked) return; const S = H.S;
    H.addStats(c.add); if (c.flag) H.setFlags([].concat(c.flag)); if (c.inc) H.incFlags([].concat(c.inc));
    S.picks.push(sc.id + ':' + idx); S.log.push({ w: '▶', t: H.fill(c.t) });
    $('choices').classList.add('hidden'); $('dialog').classList.remove('hidden');
    const to = typeof c.to === 'function' ? c.to(S) : c.to;
    E.enter(to, 0, false);
  }

  E.toggleSkip = function () { skipping = !skipping; E.syncBtns(); if (skipping && !typing) E.advance(true); };
  E.toggleAuto = function () { H.settings.auto = !H.settings.auto; H.saveSettings(); E.syncBtns(); if (H.settings.auto && !typing) done(); };
  E.syncBtns = function () { $('btnSkip').classList.toggle('on', skipping); $('btnAuto').classList.toggle('on', !!H.settings.auto); };
  E.stopSkip = function () { skipping = false; E.syncBtns(); };
})();
