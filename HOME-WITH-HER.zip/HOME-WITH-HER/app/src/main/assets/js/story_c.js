// Chapter 7–8 dan Chapter Akhir
(function () {
  const H = window.HWH, { R, M, N, T, B, TH, sc } = H;

  // ===================== CHAPTER 7 =====================
  sc('c7_start', { ch: 'c7', bg: 'bedroom', mus: 'sad', rain: true, rei: true, sum: 'Badai, listrik padam, dan permintaan untuk duduk.',
    steps: [
      N('Badai malam itu menelan seluruh gang. Listrik padam. Kamu duduk di tempat tidur dengan senter ponsel, dan Reina masuk tanpa mengetuk, membawa lilin.', 'SAD', { sfx: 'thunder' }),
      R('Boleh aku duduk di sini? Hujan seperti ini mengingatkanku pada sesuatu.'),
      R('Kamu menatapku seperti kamu sedang memutuskan sesuatu tentangku.', 'NORMAL', { cond: (s) => s.sus >= 40 }),
      N('Kamu merasakan beratnya dua hal: jarak yang ingin kamu ambil, dan kehangatan yang tidak ingin kamu lepas.')
    ],
    next: (s) => (s.aff >= 35 ? 'c7_memory' : s.clues.indexOf('photo') >= 0 ? 'c7_confront' : 'c7_deflect') });

  sc('c7_confront', { ch: 'c7', bg: 'bedroom', mus: 'tense', rain: true, rei: true,
    steps: [
      M('Reina Kurose. Lima belas tahun. Meninggal tujuh tahun lalu di Tikungan Cempaka.'),
      N('Kamu meletakkan foto itu di antara kalian. Nyala lilin menegak.', null, { fx: 'flicker' }),
      N('Reina tidak melihat foto itu. Dia menatapmu.', 'EMPTY'),
      R('Berhenti menyebut namanya seperti itu.', 'ANGRY', { add: { ins: 10 }, flag: 'forced' }),
      R('…Baik. Kamu berhak tahu. Dengarkan sampai habis. Jangan memotong.', 'SAD')
    ], next: 'c7_memory' });

  sc('c7_deflect', { ch: 'c7', bg: 'bedroom', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Aku tidak bisa menceritakannya malam ini. Aku belum yakin kamu tidak akan pergi.', 'SHY'),
      N('Kamu menunggu. Dia tidak bercerita. Hujan menelan sisa malam, dan di bahumu ada beban yang tidak punya nama.', null, { flag: 'noorigin' })
    ], next: 'c8_hub' });

  sc('c7_memory', { ch: 'c7', bg: 'bedroom', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Tujuh tahun lalu. Malam badai. Kamu empat belas tahun, tersesat di jalan raya, basah dan ketakutan.', 'SAD'),
      R('Aku bukan siapa-siapa waktu itu. Hanya sesuatu yang lapar di bawah hujan. Dan aku melihat seorang gadis berhenti.'),
      R('Dia menggenggam tanganmu, dan dia tidak lari. Orang selalu lari. Dia tinggal.', 'EMPTY'),
      R('Aku belum pernah melihat sesuatu yang sehangat itu. Seseorang yang tinggal.'),
      R('Truk itu datang. Dia mendorongmu. Dia tidak sempat tinggal lagi.', 'SAD'),
      R('Kamu menangis sambil memegang jepit rambutnya, dan setiap malam selama tujuh tahun kamu mengingat wajahnya. Itu satu-satunya hal di dunia yang menyebut sesuatu atas namaku.'),
      R('Aku mengambil wajah itu dari ingatanmu. Nama itu juga. Aku ada karena kamu mengingat dia, dan aku memilih rumah ini karena ini rumahnya.', 'NORMAL'),
      R('Kamu orang terakhir yang mengingat Reina Kurose.', null, { clue: 'origin', flag: 'origin', add: { sus: 8 } }),
      R('Aku tidak tahu apakah yang kurasakan padamu itu asli, atau tiruan dari seseorang yang dulu menyayangimu. Aku hanya tahu aku tidak mau kehilangannya.', 'SAD', { add: { ins: -4 } })
    ],
    q: 'Lilin bergetar di antara kalian.',
    choices: [
      { t: 'Kamu bukan dia. Kamu tidak berhak atas wajahnya.', add: { aff: -6, ins: 14, sus: 4 }, flag: 'harsh', to: 'c8_hub' },
      { t: 'Aku tidak tahu kamu apa. Tapi malam ini kamu tidak sendirian.', add: { aff: 10, ins: -8 }, flag: 'accepted', to: 'c8_hub' },
      { t: 'Siapa namamu yang sebenarnya?', add: { aff: 3, ins: 4 }, flag: 'asked_name', to: 'c7_name' }
    ] });

  sc('c7_name', { ch: 'c7', bg: 'bedroom', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Namaku… belum ada. Tidak ada yang pernah memanggilku apa pun selain apa yang mereka takutkan.', 'SAD'),
      N('Untuk pertama kalinya, topengnya tidak berusaha menutupi apa pun.', 'SHY'),
      R('Kalau suatu hari kamu memberiku satu, aku akan menyimpannya lebih baik daripada kamu menyimpan jepit itu.', null, { add: { aff: 5 } })
    ], next: 'c8_hub' });

  // ===================== CHAPTER 8 =====================
  sc('c8_hub', { ch: 'c8', bg: 'porch', mus: 'tense', rain: false, rei: true, sum: 'Raka datang. Tiga jalan terbuka.',
    steps: [
      N('Pagi. Hujan reda. Ada ketukan di pintu: Raka, mata merah, membawa ransel.', null, { hide: true, sfx: 'knock' }),
      T('{n}. Aku nggak basa-basi. Ikut aku. Sekarang. Aku udah cari tahu. Keluarga Kurose, Tikungan Cempaka… perempuan itu sudah mati tujuh tahun!'),
      T('Aku lihat di video itu. Itu bukan dia. Itu bukan manusia.'),
      N('Dari balik gorden, Reina memperhatikan kalian. Tanpa suara. Tanpa berkedip.', 'EMPTY', { hide: false })
    ],
    q: 'Tiga jalan terbuka di pagi yang basah ini.',
    choices: [
      { t: 'Percaya pada Reina. Suruh Raka pergi.', add: { aff: 8, sus: -5, ins: 2 }, flag: 'route_trust', to: 'c8_trust' },
      { t: 'Pergi bersama Raka. Sekarang.', add: { sus: 6 }, flag: 'route_run', to: 'c8_run' },
      { t: 'Cari kebenaran dulu: temui Bu Hartini, pergi ke makam Reina yang asli.', req: (s) => s.clues.indexOf('photo') >= 0, reqText: 'Kamu belum punya bukti tentang Reina yang asli.', add: { sus: 4 }, flag: 'route_truth', to: 'c8_truth' }
    ] });

  sc('c8_trust', { ch: 'c8', bg: 'porch', mus: 'sad', rain: false, rei: true,
    steps: [
      T('Kamu gila. Kamu bakal menyesal, {n}.', null, { hide: true }),
      N('Raka pergi dengan bahu merosot. Kamu tidak mengejarnya.'),
      R('Kamu memilihku.', 'HAPPY', { hide: false }),
      R('Tidak ada yang pernah memilihku.', 'SAD'),
      N('Dia memelukmu, dan sebentar saja kamu lupa bahwa pelukannya tidak punya detak jantung.')
    ], next: 'f_start' });

  sc('c8_run', { ch: 'c8', bg: 'street', mus: 'horror', rain: true, rei: true,
    steps: [
      N('Raka mengemudi cepat. Jalan raya basah, tikungan demi tikungan. Kamu tidak menoleh ke belakang.', null, { hide: true }),
      N('Di spion, sebuah sosok hitam berdiri di tengah jalan, melambai pelan.', 'NORMAL', { fx: 'glitch', hide: false }),
      T('Aku lihat dia juga, {n}. Jangan lihat spion!', null, { hide: true }),
      N('Ponselmu menyala. Satu pesan dari nomor tak dikenal: “Pulanglah sebelum hujan berikutnya.”', null, { sfx: 'phone', add: { ins: 4 } }),
      N('Mobil mogok tepat di Tikungan Cempaka. Hujan jatuh. Raka mengumpat, dan kamu tahu — kamu tahu — ke mana kamu harus kembali.')
    ], next: 'f_start' });

  sc('c8_truth', { ch: 'c8', bg: 'grave', mus: 'sad', rain: false, rei: false,
    steps: [
      N('Pemakaman di ujung kota, subuh. Bu Hartini sudah menunggu dengan bunga melati.', null),
      B('Ini makamnya. Reina Kurose. Nama itu masih tertulis di sini, tidak ada yang meminjamnya.'),
      B('Waktu itu aku melihat dari jendela: ada sesuatu berdiri di samping Reina sebelum truk itu datang. Bukan jahat. Mengamati. Seperti anak yang sedang belajar.', null, { cond: (s) => !s.f.origin, clue: 'origin', flag: 'origin' }),
      B('Nama yang dipinjam harus dikembalikan dengan kesadaran, bukan paksaan. Dan harus ada yang menggantikannya, atau yang tersisa hanya lapar.'),
      N('Kamu meletakkan jepit rambut perak di atas nisan, hanya sebentar, lalu mengambilnya kembali.', null, { flag: 'grave', add: { sus: 3 } }),
      TH('Aku tahu apa yang harus kulakukan. Aku hanya belum tahu apakah aku sanggup.')
    ], next: 'f_start' });

  // ===================== CHAPTER AKHIR =====================
  sc('f_start', { ch: 'c9', bg: 'living', mus: 'tense', rain: true, rei: true, sum: 'Malam terakhir. Keputusan akhir.',
    steps: [
      N('Malam terakhir. Badai paling deras yang pernah menimpa gang itu. Rumahmu menunggu dengan semua lampu menyala.', null, { hide: true, sfx: 'thunder' }),
      N('Kamu sudah memilih untuk percaya. Sekarang kamu hanya berharap pilihan itu tidak salah.', null, { cond: (s) => s.f.route_trust }),
      N('Kamu tidak pernah benar-benar pergi. Jalan selalu membawamu kembali ke Jalan Kenanga nomor 7.', null, { cond: (s) => s.f.route_run }),
      N('Jepit perak di sakumu terasa berat, dan sebuah nama terbentuk di bibirmu.', null, { cond: (s) => s.f.route_truth }),
      R('Kamu pulang.', 'AUTO', { hide: false }),
      R('Aku menyalakan semua lampu supaya kamu tidak tersesat.', 'HAPPY', { cond: (s) => s.ins < 60 }),
      R('Aku menyalakan semua lampu supaya kamu tidak tersesat. Semuanya. Semuanya. Semuanya.', 'UNNATURAL', { cond: (s) => s.ins >= 60, fx: 'flicker' }),
      R('{n}. Aku bertanya bukan sebagai tamu. Bukan sebagai bayangan seseorang. Aku bertanya sebagai yang tersisa.', 'SAD'),
      R('Apa yang kamu pilih?')
    ], next: 'f_hub' });

  sc('f_hub', { ch: 'c9', bg: 'living', mus: 'tense', rain: true, rei: true,
    steps: [N('Hujan berhenti sejenak di luar jendela, seakan menunggu jawabanmu juga.')],
    q: 'Tidak ada jalan yang tidak punya harga.',
    choices: [
      { t: 'Tinggal bersamanya. Apa pun dia.', to: (s) => H.resolveEnding('stay', s) },
      { t: 'Lari. Malam ini juga.', to: (s) => H.resolveEnding('run', s) },
      { t: 'Kembalikan nama itu pada pemiliknya. Beri dia nama yang baru.', req: (s) => s.f.origin && s.clues.indexOf('rules') >= 0 && s.aff >= 25, reqText: 'Kamu belum cukup tahu siapa dia, atau dia belum cukup percaya padamu.', to: (s) => H.resolveEnding('name', s) }
    ] });

  // Penentu ending: kombinasi flag + status + pilihan akhir (tidak ditentukan satu angka saja).
  H.resolveEnding = function (pick, s) {
    const f = s.f, lies = f.lies || 0;
    if (pick === 'name') {
      const all = s.clues.length >= 6 && f.grave && s.aff >= 45 && s.ins <= 55 && lies <= 1;
      return all ? 'e_secret' : 'e_true';
    }
    if (pick === 'run') return s.sus >= 50 ? 'e_escape' : 'e_bad';
    if (s.ins >= 65 || lies >= 3) return 'e_obsession';
    if (s.aff >= 60 && (f.forgave || f.calmed)) return 'e_love';
    if (s.sus < 55) return 'e_bad';
    return 'e_obsession';
  };
})();
