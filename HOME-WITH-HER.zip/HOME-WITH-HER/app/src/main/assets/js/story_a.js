// Prolog, Chapter 1–3
(function () {
  const { R, M, N, T, TH, sc } = window.HWH;

  // ===================== PROLOG =====================
  sc('p1', { ch: 'p', bg: 'street', mus: 'sad', rain: true, rei: true, sum: 'Bertemu Reina di bawah lampu jalan.',
    steps: [
      N('Hujan turun sejak sore. Jam di ponselmu menunjukkan 23.48, dan jalan pulang terasa dua kali lebih panjang dari biasanya.', 'NORMAL', { hide: true }),
      TH('Tinggal dua blok lagi. Teh panas, selimut, selesai.', null, { hide: true }),
      N('Lampu jalan di tikungan Jalan Kenanga mati. Di bawahnya, seseorang berdiri.', null, { hide: true, sfx: 'step' }),
      N('Seorang perempuan. Tanpa payung. Gaun hitam panjang, rambut hitam jatuh sampai pinggang.', 'NORMAL'),
      R('Kamu pulang larut sekali.', 'NORMAL'),
      M('Maaf? Kamu… kenal aku?'),
      R('Belum.', 'HAPPY'),
      R('Tapi kamu berhenti. Kebanyakan orang tidak.'),
      N('Hujan memukul aspal di sekelilingmu. Anehnya, rambutnya kering.', null, { add: { sus: 3 } }),
      R('Namaku Reina. Reina Kurose. Malam ini aku tidak punya tempat untuk pulang.', 'SAD')
    ],
    q: 'Apa yang kamu lakukan?',
    choices: [
      { t: 'Pinjamkan payungmu dan tanya apa yang terjadi.', add: { aff: 4 }, flag: 'kind', to: 'p2' },
      { t: 'Rambutmu kering. Kamu ini sebenarnya siapa?', add: { sus: 6, ins: 2 }, flag: 'probed', to: 'p2' },
      { t: 'Beri uang untuk penginapan, lalu pergi.', add: { aff: -2, sus: 3 }, flag: 'walked', to: 'p2' }
    ] });

  sc('p2', { ch: 'p', bg: 'street', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Payung… sudah lama tidak ada yang memberiku sesuatu tanpa bertanya apa yang akan ia dapat.', 'HAPPY', { cond: (s) => s.f.kind }),
      R('Orang yang teliti. Aku suka itu. Mungkin hujan di sini memang kering untukku.', 'FLIRTY', { cond: (s) => s.f.probed }),
      N('Dia bercanda. Kamu hampir yakin dia bercanda.', null, { cond: (s) => s.f.probed }),
      R('Uang ini cukup untuk satu malam.', 'SAD', { cond: (s) => s.f.walked }),
      R('Tapi aku tidak butuh kamar. Aku butuh seseorang yang mengizinkanku masuk.', null, { cond: (s) => s.f.walked }),
      R('Rumahmu dekat, kan? Aku bisa mencium bau teh dari sini.', 'NORMAL'),
      M('Aku belum bilang aku tinggal di—'),
      R('Kamu menggigil. Ayo, kita jangan berdiri di sini.', 'SHY', { add: { sus: 3 } }),
      N('Kamu seharusnya bertanya lebih jauh. Tapi dingin menggigit, dan perempuan itu menggigil dengan cara yang terlalu rapi.')
    ],
    q: 'Malam sudah larut.',
    choices: [
      { t: 'Bawa dia pulang. Hanya semalam.', add: { aff: 5 }, flag: 'brought', to: 'p3' },
      { t: 'Ajak dia ke pos satpam di ujung gang.', add: { sus: 2 }, to: 'p2b' }
    ] });

  sc('p2b', { ch: 'p', bg: 'street', mus: 'tense', rain: true, rei: true,
    steps: [
      N('Pos satpam gelap. Kursinya kosong, termos tehnya masih mengepul, tapi tak ada siapa pun.', 'NORMAL', { fx: 'flicker' }),
      R('Lihat? Tidak ada siapa-siapa.', 'NORMAL'),
      R('Hanya kamu.', 'FLIRTY', { add: { sus: 4, ins: 4 } }),
      N('Entah kenapa, kalimat itu terdengar seperti jawaban atas pertanyaan lain.'),
      M('…Baiklah. Hanya semalam.')
    ], next: 'p3' });

  sc('p3', { ch: 'p', bg: 'porch', mus: 'tender', rain: true, rei: true,
    steps: [
      N('Kamu membuka pintu rumah. Lampu teras berkedip. Reina berhenti tepat di garis ambang.', 'NORMAL'),
      R('Boleh?'),
      M('Boleh apa?'),
      R('Masuk. Aku tidak suka masuk ke rumah orang yang belum mengundangku.', 'SHY'),
      N('Sopan santun yang aneh. Dan entah kenapa, kamu merasa kalimat itu bukan soal sopan santun.')
    ],
    q: 'Dia menunggu di ambang pintu.',
    choices: [
      { t: 'Silakan masuk, Reina. Anggap rumah sendiri.', add: { aff: 3 }, flag: 'invited', to: 'p4' },
      { t: 'Kamu boleh masuk. Sampai pagi saja.', add: { aff: 1, sus: 1 }, flag: ['invited', 'limit'], to: 'p4' }
    ] });

  sc('p4', { ch: 'p', bg: 'living', mus: 'tender', rain: true, rei: true,
    steps: [
      R('Terima kasih.', 'HAPPY', { sfx: 'door' }),
      N('Saat kaki Reina melewati ambang, hujan di luar berhenti. Hanya sedetik. Lalu turun lagi, lebih deras.'),
      TH('Kebetulan.', null)
    ], next: 'c1_morning' });

  // ===================== CHAPTER 1 =====================
  sc('c1_morning', { ch: 'c1', bg: 'kitchen', mus: 'calm', rain: true, rei: true, sum: 'Pagi pertama bersama Reina.',
    steps: [
      N('Pagi. Bau kopi membangunkanmu — kopi pahit, tanpa gula, persis seperti yang kamu suka. Kamu tidak ingat punya biji kopi.', 'HAPPY'),
      R('Selamat pagi. Tidurmu nyenyak?', 'HAPPY'),
      M('Kamu masak?'),
      R('Telur dadar dan kopi. Aku tidak tahu kamu suka apa, jadi aku menebak.'),
      M('Kopinya pahit. Tepat sekali.'),
      R('Orang yang pulang jam sebelas malam dengan bahu sekaku itu tidak butuh gula.', 'FLIRTY'),
      N('Penjelasan yang masuk akal. Kamu memilih mempercayainya.'),
      R('Kamu selalu pulang selarut itu?', 'NORMAL'),
      M('Biasanya. Kenapa?'),
      R('Tidak apa-apa. Aku cuma ingin tahu kapan harus mulai merindukanmu.', 'FLIRTY'),
      N('Reina tersenyum. Dalam pantulan jendela dapur, wajahnya tidak ikut tersenyum.', null, { fx: 'flicker', add: { ins: 2 } })
    ],
    q: 'Reina menatapmu, menunggu.',
    choices: [
      { t: 'Itu manis. Aku pulang lebih awal besok.', add: { aff: 6 }, to: 'c1_day' },
      { t: 'Kamu belum cerita kamu dari mana, Reina.', add: { sus: 5, aff: -1 }, to: 'c1_ask' },
      { t: 'Aku harus kerja. Jangan buka pintu untuk siapa pun.', add: { sus: 2 }, flag: 'warned', to: 'c1_day' }
    ] });

  sc('c1_ask', { ch: 'c1', bg: 'kitchen', mus: 'calm', rain: true, rei: true,
    steps: [
      R('Dari tempat yang jauh, basah, dan tidak punya alamat.', 'NORMAL'),
      M('Itu bukan jawaban.'),
      R('Itu satu-satunya yang jujur.', 'SHY'),
      R('Tanya lagi nanti, ya? Sekarang telurnya mulai dingin.'),
      N('Dia mengalihkan topik dengan begitu halus sampai kamu baru sadar setelah piringnya kosong.', null, { add: { sus: 2 } })
    ], next: 'c1_day' });

  sc('c1_day', { ch: 'c1', bg: 'living', mus: 'calm', rain: true, rei: true,
    steps: [
      N('Sore. Ponselmu bergetar. Raka.', 'NORMAL', { hide: true, sfx: 'phone' }),
      T('Woi! Katanya kamu bawa cewek pulang? Bu Hartini sampai nanya ke Mamaku.'),
      M('Cepat sekali gosip menyebar.'),
      T('Ini gang kecil, Bro. Siapa dia? Kenalin dong. Sabtu aku ke sana, ya?'),
      N('Dari lorong, kamu merasakan sesuatu. Reina berdiri di sana tanpa suara, menatap ponselmu seperti menatap sesuatu yang menggigit.', 'EMPTY'),
      R('Temanmu bicara terlalu banyak.', 'JEALOUS', { add: { ins: 2 } })
    ],
    q: 'Raka menunggu jawabanmu.',
    choices: [
      { t: 'Boleh, Sabtu datang aja.', add: { aff: -3, sus: -1, ins: 4 }, flag: 'raka_invited', to: 'c1_night' },
      { t: 'Jangan dulu, Rak. Lagi capek. Nanti kukabari.', add: { aff: 3, ins: 2 }, inc: 'lies', to: 'c1_night' }
    ] });

  sc('c1_night', { ch: 'c1', bg: 'living', mus: 'tender', rain: true, rei: true,
    steps: [
      N('Malam. Hujan lagi. Reina duduk di lengan sofa, kakinya terlipat, memperhatikan lampu meja seolah belum pernah melihat cahaya sehangat itu.', 'NORMAL'),
      R('Kamu berbohong pada temanmu. Demi aku.', 'HAPPY', { cond: (s) => s.f.lies >= 1 }),
      R('Aku tidak tahu harus merasa bersalah atau senang. Kurasa… senang.', 'SHY', { cond: (s) => s.f.lies >= 1 }),
      R('Dia akan datang hari Sabtu. Aku akan bersikap baik.', 'UNNATURAL', { cond: (s) => s.f.raka_invited, fx: 'flicker', add: { ins: 4 } }),
      N('Kamu menyodorkan selimut. Reina menerimanya, dan bayangannya di dinding tertinggal setengah detik di belakang gerakannya.', 'NORMAL', { clue: 'shadow', fx: 'glitch' }),
      TH('Setengah detik. Kamu mengedip, dan bayangan itu sudah sinkron lagi. Capek, mungkin.'),
      R('Kenapa menatapku begitu?', 'FLIRTY'),
      R('Kamu mau bilang sesuatu?', null, { cond: (s) => s.aff >= 30 }),
      R('Kamu terlalu banyak berpikir. Pelan-pelan saja.', 'SHY', { cond: (s) => s.aff < 30 })
    ],
    q: 'Malam yang tenang, setidaknya di permukaan.',
    choices: [
      { t: 'Duduk di sebelahnya. Menonton hujan bersama.', add: { aff: 6, ins: -2 }, to: 'c2_bath' },
      { t: 'Perhatikan bayangannya diam-diam.', add: { sus: 6, ins: 3 }, flag: 'watched_shadow', to: 'c2_bath' },
      { t: 'Pamit tidur duluan.', add: { sus: 1 }, to: 'c2_bath' }
    ] });

  // ===================== CHAPTER 2 =====================
  sc('c2_bath', { ch: 'c2', bg: 'bath', mus: 'tense', rain: true, rei: true, sum: 'Pantulan Reina di cermin kamar mandi.',
    steps: [
      N('Dini hari. Kamu menyikat gigi dengan mata setengah terpejam. Keran menetes. Cermin berembun, dan kamu mengusapnya dengan telapak tangan.', null, { hide: true }),
      N('Di cermin, di belakang bahumu, Reina berdiri di ambang pintu kamar mandi.', 'NORMAL', { sfx: 'step' }),
      N('Pantulannya tidak tersenyum. Matanya tidak berkedip. Dan mulutnya… terlalu lebar.', 'UNNATURAL', { fx: 'glitch', clue: 'mirror', add: { ins: 3 } }),
      N('Kamu berbalik. Tidak ada siapa-siapa. Pintu kamar mandi tertutup — terkunci dari dalam.', null, { hide: true }),
      TH('Terkunci. Dari dalam.'),
      R('{n}? Kamu lama sekali. Aku khawatir.', 'NORMAL', { sfx: 'knock', hide: true })
    ],
    q: 'Suaranya lembut. Sangat lembut.',
    choices: [
      { t: 'Buka pintu dan tatap dia langsung.', add: { sus: 5, ins: 4 }, to: 'c2_face' },
      { t: 'Bilang kamu baik-baik saja, lalu cepat keluar.', add: { aff: 1 }, inc: 'lies', to: 'c2_pretend' },
      { t: 'Lihat cermin sekali lagi, sendirian.', add: { sus: 4, ins: 6 }, flag: 'lookedagain', to: 'c2_again' }
    ] });

  sc('c2_face', { ch: 'c2', bg: 'hall', mus: 'tense', rain: true, rei: true,
    steps: [
      R('Kamu pucat. Mimpi buruk?', 'NORMAL'),
      M('Aku melihat kamu di cermin. Tapi bukan kamu.'),
      N('Keheningan menetap. Detik demi detik. Dia tidak bernapas — atau kamu tidak mendengarnya bernapas.', 'EMPTY'),
      R('Cermin itu jujur pada hal-hal yang tidak ingin kujawab.'),
      R('Jangan marah. Aku tidak suka cermin. Tidak pernah.', 'SHY'),
      N('Dia meraih lenganmu. Tangannya dingin, tapi jemarinya gemetar. Entah dia takut padamu, atau takut kamu takut.')
    ],
    q: 'Dia masih memegang lenganmu.',
    choices: [
      { t: 'Aku tidak marah. Tapi aku mau tahu.', add: { sus: 3, aff: 2 }, flag: 'asked_mirror', to: 'c3_dinner' },
      { t: 'Tidak apa-apa. Aku cuma capek.', add: { aff: 4, sus: -2 }, to: 'c3_dinner' }
    ] });

  sc('c2_pretend', { ch: 'c2', bg: 'kitchen', mus: 'tense', rain: true, rei: true,
    steps: [
      R('Syukurlah. Aku sudah siapkan teh.', 'HAPPY'),
      N('Di dapur, di antara uap teh, dia menatapmu terlalu lama.'),
      R('Kamu tidak pandai berbohong. Tapi aku suka kamu mencoba.', 'FLIRTY', { fx: 'flicker', add: { ins: 3 } })
    ], next: 'c3_dinner' });

  sc('c2_again', { ch: 'c2', bg: 'bath', mus: 'horror', rain: true, rei: true,
    steps: [
      N('Sendirian. Hanya kamu di kaca; wajahmu lelah. Lalu kaca di sebelahmu bergerak.', null, { hide: true }),
      N('Pantulanmu tersenyum satu detik sebelum kamu.', null, { fx: 'glitch' }),
      N('Sesuatu menempel dari sisi lain kaca. Wajah itu menekan permukaan dingin, dan senyumnya hampir menyentuh telinga.', 'MONSTER', { fx: 'jump', add: { ins: 4, sus: 3 } }),
      N('Kamu mundur. Cermin kembali normal. Di embun, tertulis oleh sebuah jari: “TINGGAL.”', null, { hide: true })
    ], next: 'c3_dinner' });

  // ===================== CHAPTER 3 =====================
  sc('c3_dinner', { ch: 'c3', bg: 'kitchen', mus: 'tender', rain: true, rei: true, sum: 'Makan malam dan permintaan untuk tinggal.',
    steps: [
      N('Seminggu berlalu. Rumah kecilmu tidak lagi terasa kecil, hanya penuh. Anehnya, kamu mulai menyukainya.', 'HAPPY'),
      R('Aku masak rendang. Resepnya dari… entah dari mana. Rasanya mirip rumah, kan?'),
      M('Mirip rumah siapa?'),
      R('Rumah yang belum pernah kutinggali.', 'SAD'),
      N('Dia tersenyum, tapi kamu menangkap sesuatu seperti iri.'),
      R('Aku selalu membersihkan piring dengan satu gerakan. Kamu perhatikan? Orang bilang itu tanda orang yang takut ditinggal.', 'NORMAL', { cond: (s) => s.ins >= 40 }),
      R('Boleh aku jujur? Aku suka cara kamu memandangku saat kamu pikir aku tidak melihat.', 'FLIRTY'),
      M('Aku tidak—'),
      R('Aku selalu melihat.', null, { add: { aff: 3 } }),
      R('{n}, aku mau tanya sesuatu. Kalau aku bilang aku ingin tinggal lebih lama dari yang kamu rencanakan…', 'SHY'),
      R('…kamu akan membuka pintu, atau menutupnya?')
    ],
    q: 'Jemarinya mengetuk pelan tepi piring.',
    choices: [
      { t: 'Tinggallah selama kamu mau.', add: { aff: 8, ins: -3 }, flag: 'promised', to: 'c3_conflict' },
      { t: 'Sampai kamu punya tempat sendiri.', add: { aff: -3, ins: 6, sus: 2 }, to: 'c3_conflict' },
      { t: 'Beri aku waktu. Semuanya terlalu cepat.', add: { sus: 3, ins: 4 }, to: 'c3_conflict' }
    ] });

  sc('c3_conflict', { ch: 'c3', bg: 'bedroom', mus: 'tense', rain: true, rei: true,
    steps: [
      N('Dua hari kemudian kamu pulang dan menemukan Reina di kamarmu, diam di depan lemari, memegang kenop laci yang terkunci.', 'EMPTY'),
      R('Laci ini selalu terkunci. Isinya apa?'),
      M('Barang lama.'),
      R('Aku tahu itu “barang lama”. Aku tanya barang siapa.'),
      N('Nada suaranya masih lembut. Tapi kata-katanya tidak punya napas.'),
      R('Aku tidak suka ada pintu yang tidak boleh kubuka di rumah ini. Rumah ini rumahku juga, kan?', 'JEALOUS', { add: { ins: 3 } }),
      TH('Jepit rambut perak. Satu-satunya yang kuselamatkan dari malam itu.')
    ],
    q: 'Benda itu belum pernah kamu tunjukkan pada siapa pun.',
    choices: [
      { t: 'Kutunjukkan. Tapi jangan tanya apa-apa sekarang.', add: { aff: 4, sus: -2, ins: 2 }, flag: 'showed_pin', to: 'c4_knew' },
      { t: 'Itu privasiku, Reina.', add: { sus: 2, ins: 8, aff: -2 }, flag: 'refused', to: 'c4_knew' },
      { t: 'Cuma kenang-kenangan dari nenekku.', add: { ins: 10 }, inc: 'lies', flag: 'lied_pin', to: 'c4_knew' }
    ] });
})();
