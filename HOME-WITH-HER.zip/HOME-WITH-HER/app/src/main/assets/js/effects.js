(function () {
  const H = window.HWH;
  const $ = (id) => document.getElementById(id);
  let drops = [], raf = null, quality = 'high', rainOn = false;
  const cv = () => $('rain');

  function resize() { const c = cv(); c.width = c.clientWidth; c.height = c.clientHeight; }
  function setupDrops() {
    const n = quality === 'low' ? 40 : quality === 'mid' ? 90 : 160; drops = [];
    const c = cv();
    for (let i = 0; i < n; i++) drops.push({ x: Math.random() * c.width, y: Math.random() * c.height, l: 8 + Math.random() * 16, v: 9 + Math.random() * 10 });
  }
  function loop() {
    raf = requestAnimationFrame(loop);
    const c = cv(), g = c.getContext('2d');
    g.clearRect(0, 0, c.width, c.height);
    if (!rainOn) return;
    g.strokeStyle = 'rgba(190,200,230,.45)'; g.lineWidth = 1; g.beginPath();
    drops.forEach((d) => {
      g.moveTo(d.x, d.y); g.lineTo(d.x - 2, d.y + d.l);
      d.y += d.v; d.x -= 0.8;
      if (d.y > c.height) { d.y = -20; d.x = Math.random() * (c.width + 40); }
    });
    g.stroke();
  }

  H.fx = {
    init() { resize(); setupDrops(); window.addEventListener('resize', () => { resize(); setupDrops(); }); if (!raf) loop(); },
    setQuality(q) { quality = q; if (cv().width) setupDrops(); },
    rain(on) { rainOn = !!on; H.audio.rain(!!on); },
    toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(H.fx._tt); H.fx._tt = setTimeout(() => t.classList.remove('on'), 2300); },
    cls(el, c, ms) { el.classList.remove(c); void el.offsetWidth; el.classList.add(c); setTimeout(() => el.classList.remove(c), ms); },
    shake() { H.fx.cls($('app'), 'fx-shake', 500); },
    flicker() { if (H.settings.noflash) return; H.fx.cls($('stage'), 'fx-flicker', 1100); },
    glitch() { if (H.settings.noflash) { H.fx.shake(); return; } H.fx.cls($('stage'), 'fx-glitch', 1100); H.audio.sfx('hum', H.settings.softjump); },
    flash() {
      if (H.settings.noflash) return;
      const f = $('vfx-flash'); f.style.transition = 'none'; f.style.opacity = '.85'; void f.offsetWidth;
      f.style.transition = 'opacity .4s'; f.style.opacity = '0';
    },
    fade(on, ms) { const f = $('fade'); f.style.transition = 'opacity ' + ((ms || 600) / 1000) + 's'; f.classList.toggle('on', !!on); },
    jumpscare() {
      const s = H.settings;
      if (!s.jump) { H.fx.shake(); H.audio.sfx('hum', true); return; }   // jumpscare dimatikan: hanya getar halus
      const j = $('jump'); j.innerHTML = H.portrait('MONSTER', 100, true);
      j.classList.add('on'); H.audio.sfx('sting', s.softjump); if (!s.softjump) H.fx.shake(); H.fx.flash();
      setTimeout(() => j.classList.remove('on'), s.softjump ? 450 : 750);
    },
    setIns() {
      const b = document.body; b.classList.remove('ins1', 'ins2', 'ins3');
      const l = H.insLevel(); if (l) b.classList.add('ins' + l);
    }
  };
  H.toast = (m) => H.fx.toast(m);
})();
