// Chapter 4–6
(function () {
  const { R, M, N, T, B, TH, sc } = window.HWH;

  // ===================== CHAPTER 4 =====================
  sc('c4_knew', { ch: 'c4', bg: 'living', mus: 'tense', rain: true, rei: true, sum: 'Reina tahu hal yang tak pernah kamu ceritakan.',
    steps: [
      N('Malam itu hujan turun deras sampai atap bergetar.', 'NORMAL'),
      R('Jepit rambut perak, dengan huruf R di baliknya. Terima kasih sudah menunjukkannya. Dan terima kasih sudah menyimpannya tujuh tahun.', 'SAD', { cond: (s) => s.f.showed_pin }),
      M('Aku tidak bilang sudah tujuh tahun.', null, { cond: (s) => s.f.showed_pin }),
      R('Jepit perak. Huruf R di baliknya. Kamu menyimpannya tujuh tahun karena tidak sanggup membuangnya.', 'UNNATURAL', { cond: (s) => !s.f.showed_pin, fx: 'glitch', add: { ins: 3 } }),
      R('Bohong. Itu bukan dari nenekmu.', null, { cond: (s) => s.f.lied_pin, add: { ins: 3 } }),
      M('Aku tidak pernah menceritakan itu. Pada siapa pun.', null, { cond: (s) => !s.f.showed_pin }),
      N('Tidak pada Raka. Tidak pada polisi. Tidak pada psikolog sekolah.', null, { clue: 'knew', add: { sus: 6 } }),
      R('Kamu bicara dalam tidurmu, mungkin.', 'HAPPY'),
      R('Atau aku hanya pandai menebak.', 'FLIRTY'),
      TH('Dua penjelasan. Dua-duanya tidak cukup.')
    ], next: 'c4_hub' });

  sc('c4_hub', { ch: 'c4', bg: 'living', mus: 'tense', rain: true, rei: false,
    steps: [N('Reina sudah tertidur — atau berpura-pura. Kamu punya waktu beberapa jam untuk mencari tahu siapa dia.', null)],
    q: 'Ke mana kamu mencari jawaban?',
    choices: [
      { t: 'Naik ke loteng: kotak peninggalan penghuni lama.', hide: (s) => s.f.did_attic, to: 'c4_attic' },
      { t: 'Temui Bu Hartini, tetangga yang paling lama di gang.', hide: (s) => s.f.did_neigh, to: 'c4_neigh' },
      { t: 'Cukup untuk malam ini.', req: (s) => s.f.did_attic || s.f.did_neigh, reqText: 'Selidiki sesuatu dulu.', to: 'c5_video' }
    ] });

  sc('c4_attic', { ch: 'c4', bg: 'attic', mus: 'tense', rain: true, rei: false,
    steps: [
      N('Loteng berbau debu dan hujan lama. Rumah ini bukan milikmu sejak awal; kamu membelinya murah dari agen: “penghuni sebelumnya pindah mendadak.”'),
      N('Di bawah kain putih, sebuah kotak karton bertuliskan spidol: KUROSE.'),
      TH('Kurose.'),
      N('Di dalam: album, kartu pelajar, dan selembar foto. Satu keluarga di depan rumah ini, catnya masih baru. Seorang gadis lima belas tahun berdiri di tengah — rambut hitam panjang, mata yang terlalu kamu kenal.'),
      N('Kamu membalik foto. Tulisan tangan: “Reina, 15 tahun. Sebelum hujan.”', null, { clue: 'photo', flag: 'did_attic', add: { sus: 10 } }),
      TH('Reina Kurose. Wajahnya persis sama. Tapi foto ini diambil lebih dari tujuh tahun lalu.'),
      N('Di bawah tangga, langkah-langkah pelan berhenti. Kamu menyelipkan foto itu ke saku.', null, { sfx: 'step' })
    ], next: 'c4_hub' });

  sc('c4_neigh', { ch: 'c4', bg: 'porch', mus: 'sad', rain: true, rei: false,
    steps: [
      B('Nak {n}. Duduk, duduk. Jarang kamu mampir.'),
      M('Bu, boleh tanya soal penghuni rumah sebelum saya? Keluarga Kurose?'),
      B('…Sudah lama tidak ada yang menyebut nama itu.'),
      B('Mereka keluarga baik. Anak perempuannya, Reina, manis dan pemberani. Tujuh tahun lalu, malam badai, dia meninggal di jalan raya dekat Tikungan Cempaka. Katanya dia menyelamatkan seorang anak laki-laki yang tersesat.'),
      TH('Tujuh tahun lalu. Tikungan Cempaka. Badai. Gadis itu tidak pernah menyebut namanya. Hanya genggaman tangannya, dan jepit perak ini.'),
      B('Sejak itu keluarganya pindah. Neneknya sempat menulis sesuatu di pintu dapur sebelum pergi. “Untuk yang tinggal berikutnya.” Ibu tidak pernah berani baca.'),
      B('Nak… jangan undang apa pun masuk ke rumah itu kalau namanya bukan namanya.', null, { flag: ['did_neigh', 'door_hint'], add: { sus: 8 } })
    ], next: 'c4_hub' });

  // ===================== CHAPTER 5 =====================
  sc('c5_video', { ch: 'c5', bg: 'bedroom', mus: 'tense', rain: true, rei: true, sum: 'Panggilan video Raka dan insiden dapur.',
    steps: [
      N('Pukul dua dini hari. Panggilan video dari Raka.', 'NORMAL', { hide: true, sfx: 'phone' }),
      T('Bro! Maaf jam segini. Tadi sore aku ketemu Bu Hartini, dia bilang—'),
      T('Tunggu. Kamu sendirian? Kenapa bayangan di belakangmu… begitu?'),
      N('Kamu menoleh. Reina berdiri di ambang pintu, tersenyum, tangan di belakang punggung. Di layar ponsel, sosok di belakangmu tidak berbentuk perempuan sama sekali.', 'NORMAL', { fx: 'glitch' }),
      T('{n}, jangan menoleh lagi! Itu bukan—', null, { sfx: 'hum' }),
      N('Layar padam. Lampu kamar berkedip.', null, { fx: 'flicker' }),
      R('Temanmu melihatku.', 'JEALOUS'),
      R('Aku tidak suka dilihat oleh orang yang tidak kamu lindungi dariku.', 'UNNATURAL', { add: { ins: 10, sus: 5, aff: -3 } })
    ], next: 'c5_incident' });

  sc('c5_incident', { ch: 'c5', bg: 'kitchen', mus: 'horror', rain: true, rei: true,
    steps: [
      N('Seluruh rumah padam. Kamu turun ke dapur dengan senter ponsel. Reina sudah di sana, di ujung ruangan, berdiri terlalu tegak.', 'EMPTY', { fx: 'flicker' }),
      R('Kamu tidak menjawabku. Kamu selalu menjawab.', 'UNNATURAL', { sfx: 'whisper' }),
      N('Kepalanya miring, pelan… terlalu pelan… lalu tiba-tiba terlalu jauh.', null, { fx: 'glitch' }),
      R('KENAPA KAMU TAKUT PADAKU?', 'MONSTER', { fx: 'jump', add: { ins: 10 } }),
      N('Di antara kilat, sesuatu yang bukan manusia berdiri di dapurmu. Dan ia masih menyisakan wajah Reina di tepi-tepinya.', null, { sfx: 'thunder' })
    ],
    q: 'Apa yang kamu lakukan?',
    choices: [
      { t: 'Panggil namanya pelan. “Reina. Reina, lihat aku.”', add: { aff: 4, ins: -12 }, flag: 'calmed', to: 'c5_after' },
      { t: 'Lari ke pintu depan.', add: { sus: 6, ins: 10, aff: -4 }, flag: 'tried_run', to: 'c5_door' },
      { t: 'Berteriak minta tolong.', add: { ins: 15, aff: -6 }, to: 'c5_door' }
    ] });

  sc('c5_door', { ch: 'c5', bg: 'hall', mus: 'horror', rain: true, rei: true,
    steps: [
      N('Pintu depan tidak mau terbuka. Kenopnya dingin seperti es.', null, { hide: true, add: { ins: 4, sus: 3 } }),
      R('Pintu itu menurutiku sekarang. Jangan lari. Aku tidak suka mengejar.', 'EMPTY', { sfx: 'whisper' }),
      N('Kamu berbalik. Reina berdiri tepat di depanmu, dan kamu tidak mendengarnya bergerak.'),
      R('Maaf.', 'SAD')
    ], next: 'c5_after' });

  sc('c5_after', { ch: 'c5', bg: 'living', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Maaf. Aku tidak bermaksud. Aku hanya takut.', 'SAD'),
      N('Wajahnya kembali. Terlalu cepat, seperti seseorang memakai topeng yang sudah terlalu sering dipakai.'),
      R('Aku tidak tahu harus bagaimana kalau ada yang melihatku apa adanya. Biasanya mereka… pergi.'),
      N('Dia menunggu vonismu. Tangannya mengepal di pangkuan, seperti anak kecil yang takut dimarahi.')
    ],
    q: 'Kamu bisa menjawab dengan banyak cara.',
    choices: [
      { t: 'Aku di sini. Aku tidak ke mana-mana.', add: { aff: 8, ins: -8 }, flag: 'forgave', to: 'c6_door' },
      { t: 'Kamu harus jujur padaku. Sekarang. Siapa kamu?', add: { sus: 6, ins: 6, aff: -2 }, flag: 'demanded', to: 'c5_truth' },
      { t: 'Aku butuh waktu sendiri.', add: { aff: -4, sus: 4, ins: 3 }, to: 'c6_door' }
    ] });

  sc('c5_truth', { ch: 'c5', bg: 'living', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Belum.', 'SAD'),
      R('Kalau kukatakan sekarang, kamu akan pergi sebelum kamu mengerti.'),
      R('Beri aku sedikit waktu. Dan kumohon jangan tanya pada orang yang salah.', 'SHY')
    ], next: 'c6_door' });

  // ===================== CHAPTER 6 =====================
  sc('c6_door', { ch: 'c6', bg: 'kitchen', mus: 'tense', rain: false, rei: false, sum: 'Menemukan aturan rumah di balik pintu dapur.',
    steps: [
      N('Pagi berikutnya, Reina keluar “mencari udara”. Kamu tidak yakin dia butuh udara. Kamu membuka pintu dapur belakang yang jarang kamu sentuh.'),
      N('Di balik daun pintu, di cat yang mengelupas, ada tulisan tangan tinta hitam — rapi tapi bergetar, tulisan seorang nenek. Judulnya: “UNTUK YANG TINGGAL BERIKUTNYA.”'),
      N('“Satu. Dia masuk karena diundang. Undangan bertahan selama ada yang mengingat dan memanggilnya.”', null, { sfx: 'chime' }),
      N('“Dua. Cermin tidak berbohong tentang apa dia. Dia menghindari kaca dan air yang diam.”'),
      N('“Tiga. Wajah dan nama itu pinjaman. Kalau dikembalikan kepada yang punya, dia terlepas dari rumah ini — dan dari kamu.”'),
      N('“Empat. Jangan pernah membuatnya merasa dilupakan. Yang paling berbahaya darinya bukan lapar. Melainkan takut ditinggal.”', null, { clue: 'rules', add: { sus: 8 } }),
      TH('Dia. Bukan “anak itu”. Bukan “perempuan itu”. Neneknya sudah tahu apa dia.')
    ], next: 'c6_talk' });

  sc('c6_talk', { ch: 'c6', bg: 'kitchen', mus: 'tense', rain: true, rei: true,
    steps: [
      N('Pintu depan terbuka. Reina masuk membawa roti hangat dari warung, senyumnya pas, nyaris sempurna.', 'HAPPY'),
      R('Aku bawa roti. Kamu berdiri di depan pintu itu lama sekali…', 'SHY'),
      R('…kamu sudah membacanya?', null, { fx: 'flicker' })
    ],
    q: 'Reina menatap daun pintu, lalu menatapmu.',
    choices: [
      { t: 'Sudah. Aku ingin kamu jujur soal itu.', add: { sus: 2, aff: 2 }, flag: 'confessed_read', to: 'c6_honest' },
      { t: 'Cuma melihat cat yang mengelupas.', add: { ins: 6 }, inc: 'lies', to: 'c6_lie' },
      { t: 'Aku mencabut undanganku. Keluar dari rumahku.', add: { aff: -12, ins: 18, sus: 4 }, flag: 'revoked', to: 'c6_revoke' }
    ] });

  sc('c6_honest', { ch: 'c6', bg: 'kitchen', mus: 'sad', rain: true, rei: true,
    steps: [
      R('Nenek itu tidak pernah menyukaiku. Dia benar tentang banyak hal.', 'SAD'),
      R('Aku tidak akan menyangkalnya. Dan aku tidak akan menjelaskan semuanya hari ini.'),
      R('Tapi satu hal: aku tidak berbohong soal rasa. Itu satu-satunya yang tidak kupinjam.', 'SHY', { add: { aff: 5, ins: -4 } })
    ], next: 'c7_start' });

  sc('c6_lie', { ch: 'c6', bg: 'kitchen', mus: 'tense', rain: true, rei: true,
    steps: [
      R('Ah. Kamu tidak berbohong dengan baik, sayang.', 'HAPPY'),
      R('Tapi aku akan pura-pura percaya.', 'UNNATURAL', { add: { ins: 4 } }),
      N('Senyumnya tidak berubah. Terlalu lama tidak berubah.', null, { fx: 'flicker' })
    ], next: 'c7_start' });

  sc('c6_revoke', { ch: 'c6', bg: 'kitchen', mus: 'horror', rain: true, rei: true,
    steps: [
      N('Udara menegang. Reina tidak keluar. Wajahnya retak dengan cara yang tidak berbunyi.', 'ANGRY', { fx: 'glitch', sfx: 'thunder' }),
      R('Kamu pikir aku bisa dikeluarkan?', 'EMPTY'),
      R('Aku ada karena kamu mengingatku, {n}. Kamu tidak bisa mengusir sesuatu yang kamu ingat.'),
      N('Lalu dia menangis tanpa suara. Air mata hitam di pipi pucat.', 'SAD'),
      R('Jangan lakukan itu lagi. Tolong.')
    ], next: 'c7_start' });
})();
