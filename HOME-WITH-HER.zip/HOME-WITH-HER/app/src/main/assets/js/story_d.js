// Ending + epilog (6 ending, masing-masing punya adegan penutup sendiri)
(function () {
  const { R, M, N, T, B, TH, sc } = window.HWH;

  sc('e_true', { ch: 'e', bg: 'living', mus: 'sad', rain: true, rei: true, end: 'true', sum: 'Ending: Namamu Sendiri',
    steps: [
      M('Reina Kurose sudah mati tujuh tahun lalu. Kamu bukan dia.', null),
      R('Aku tahu.', 'SAD'),
      M('Terima kasih sudah memakai wajahnya. Dia akan senang diingat. Sekarang kembalikan.'),
      N('Wajah itu bergetar, kabur, lalu perlahan terlepas seperti kabut dari kaca. Yang tersisa adalah wajah yang belum pernah kamu lihat — sederhana, takut, dan sangat nyata.', 'EMPTY', { fx: 'glitch', sfx: 'hum' }),
      M('Namamu… Rinai. Seperti hujan yang pelan.'),
      R('Rinai.', 'HAPPY', { sfx: 'chime' }),
      R('Rinai. Aku menyimpannya.', 'SAD'),
      N('Dia tidak tahu berapa lama ia bisa bertahan. Kamu tidak tahu berapa lama kamu bisa mengingat. Tapi pagi itu, di dapur, ada dua cangkir kopi, dan satu nama baru yang dipanggil berulang-ulang.'),
      N('EPILOG — Setiap tahun, pada hari badai itu, kamu meletakkan melati di sebuah nisan. Dan di jendela rumah, untuk pertama kalinya, pantulan Rinai tersenyum bersamaan dengan dirinya.')
    ] });

  sc('e_love', { ch: 'e', bg: 'bedroom', mus: 'tender', rain: true, rei: true, end: 'love', sum: 'Ending: Tinggal Selamanya',
    steps: [
      M('Aku tinggal, Reina. Kamu atau bukan siapa pun, aku tinggal.', null),
      R('Kamu serius.', 'HAPPY', { add: { aff: 5 } }),
      R('Tidak ada yang pernah serius soal tinggal.', 'SHY'),
      N('Bulan-bulan berikutnya manis seperti madu yang terlalu lama dibiarkan terbuka. Rumah itu hangat. Dunia di luar pintu mengecil.'),
      N('Ponselmu tidak lagi berdering. Nomor Raka tidak ada di daftar kontak. Bu Hartini menatapmu dari seberang gang seperti menatap orang yang sudah dikubur.', null, { fx: 'flicker' }),
      R('Kamu tidak butuh mereka. Kamu punya aku.', 'FLIRTY'),
      TH('Aku punya dia. Itu cukup. Itu… cukup, kan?'),
      N('EPILOG — Kamu bahagia. Di jendela dapur, pantulanmu tersenyum lebar. Begitu lebar sampai kamu tidak ingat kapan terakhir kali kamu berhenti tersenyum.', 'UNNATURAL')
    ] });

  sc('e_obsession', { ch: 'e', bg: 'hall', mus: 'horror', rain: true, rei: true, end: 'obsession', sum: 'Ending: Tak Akan Pernah Pergi',
    steps: [
      M('Aku… tinggal.', null),
      R('Kamu ragu.', 'EMPTY'),
      R('Kamu ragu, dan keraguan itu bau pintu.', 'UNNATURAL', { fx: 'glitch' }),
      N('Tidak ada rantai. Tidak ada gembok. Pintu depan hanya menolak terbuka setiap kali kamu menyentuh kenopnya, seperti rumah itu sendiri yang menyayangimu.'),
      R('Aku tidak akan menyakitimu. Aku hanya akan memastikan kamu tidak pernah punya alasan untuk pergi.', 'HAPPY'),
      N('Hari berganti dengan cara yang lembut dan mengerikan. Dia menyuapimu makan. Dia menyebut namamu seratus kali sehari, supaya kamu tidak lupa bahwa kamu ada karena dia.'),
      N('EPILOG — Di balik gorden, hujan turun. Kamu tidak lagi ingat wajah di dunia luar. Hanya satu wajah, yang tersenyum, yang tidak pernah berkedip.', 'MONSTER', { fx: 'jump' })
    ] });

  sc('e_escape', { ch: 'e', bg: 'street', mus: 'sad', rain: true, rei: true, end: 'escape', sum: 'Ending: Hujan di Kota Lain',
    steps: [
      M('Maaf, Reina. Aku tidak bisa.', null),
      R('Aku tahu.', 'SAD'),
      R('Pergilah. Kalau aku mengejar, aku tidak akan bisa berhenti.', 'EMPTY'),
      N('Kamu berlari dalam hujan. Raka menunggu di ujung gang dengan mesin menyala. Kamu tidak menoleh.'),
      N('Kota baru. Pekerjaan baru. Rumah kontrakan kecil dengan jendela menghadap tembok.', null, { hide: true }),
      N('Tapi setiap kali hujan turun, ada seseorang berdiri di bawah lampu jalan yang mati di ujung gang. Tidak pernah mendekat. Tidak pernah pergi.'),
      N('EPILOG — Kamu mengunci pintu dua kali. Kamu tidak pernah mengundang siapa pun masuk lagi. Dan setiap malam, tepat tengah malam, ada tiga ketukan lembut yang tidak pernah kamu jawab.', null, { sfx: 'knock' })
    ] });

  sc('e_bad', { ch: 'e', bg: 'kitchen', mus: 'horror', rain: true, rei: true, end: 'bad', sum: 'Ending: Tamu di Rumahmu Sendiri',
    steps: [
      M('Aku percaya padamu. Apa pun yang terjadi.', null, { cond: (s) => !s.f.route_run }),
      M('Aku tidak tahu apa yang kulawan. Aku hanya… capek.', null, { cond: (s) => !!s.f.route_run }),
      R('Terima kasih. Itu yang kuperlukan.', 'HAPPY'),
      N('Kamu tidak pernah memahami sampai terlambat. Malam itu dia memelukmu, dan di dalam pelukan itu ingatanmu mengalir keluar seperti air dari tangan: nama temanmu, wajah ibumu, bahkan namamu sendiri.', null, { fx: 'glitch', sfx: 'hum' }),
      N('Pagi harinya, Raka mengetuk pintu rumahmu dengan wajah khawatir.'),
      N('Yang membuka pintu adalah kamu. Tersenyum. Terlalu lebar.', 'UNNATURAL'),
      N('EPILOG — Dari dalam cermin kamar mandi, kamu yang sebenarnya melihat semuanya. Tidak ada yang mendengar ketukanmu pada kaca.', null, { sfx: 'knock' })
    ] });

  sc('e_secret', { ch: 'e', bg: 'grave', mus: 'tender', rain: false, rei: true, end: 'secret', sum: 'Ending: Rumah Tanpa Hujan',
    steps: [
      N('Subuh. Kalian berdiri di depan nisan Reina Kurose. Untuk pertama kalinya dalam tujuh tahun, tidak ada awan di atas kepala kalian.', 'NORMAL'),
      M('Kembalikan padanya. Dengan sadar, bukan paksaan.', null),
      R('Terima kasih sudah mengingatnya sebagai dirinya, bukan sebagai aku.', 'SAD'),
      N('Wajah itu terlepas pelan. Kali ini tidak ada teriakan, tidak ada retakan. Hanya satu napas panjang, seolah ia baru saja melepas sesuatu yang dipanggul tujuh tahun.', 'EMPTY', { sfx: 'chime' }),
      M('Rinai. Aku ingin memanggilmu begitu.'),
      R('Rinai. Dan kamu akan menyimpanku?', 'HAPPY'),
      M('Selama aku hidup. Dan aku akan menceritakanmu pada Raka dan Bu Hartini, supaya kamu punya lebih dari satu orang yang mengingat.'),
      N('Kamu menyadari rahasia terakhir aturan rumah: ia tidak perlu takut dilupakan kalau ada banyak orang yang memanggilnya dengan nama yang benar.'),
      N('EPILOG — Pagi itu, di Jalan Kenanga nomor 7, hujan tidak turun. Di jendela, pantulan Rinai tersenyum bersamaan dengan dirinya. Raka mengetuk pintu dengan sekantong roti, dan dia — dia membukanya sendiri.')
    ] });
})();
