(function () {
  const H = window.HWH;
  const KEY = 'hwh.settings.v1';
  const DEF = { master: 80, music: 70, sfx: 80, textSpeed: 3, auto: false, fontSize: 17,
    skipRead: true, noflash: false, softjump: false, jump: true, fxq: 'high', meters: false };

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return Object.assign({}, DEF);
      const o = JSON.parse(raw);
      return Object.assign({}, DEF, o && typeof o === 'object' ? o : {});
    } catch (e) { return Object.assign({}, DEF); }
  }
  H.settings = load();
  H.CPS = { 1: 20, 2: 35, 3: 60, 4: 100, 5: 0 };

  H.saveSettings = function () {
    try { localStorage.setItem(KEY, JSON.stringify(H.settings)); } catch (e) { /* abaikan */ }
  };
  H.applySettings = function () {
    const s = H.settings;
    document.documentElement.style.setProperty('--fs', s.fontSize + 'px');
    document.body.classList.toggle('noflash', !!s.noflash);
    document.body.classList.toggle('softjump', !!s.softjump);
    if (H.audio) H.audio.setVolumes();
    if (H.fx && H.fx.setQuality) H.fx.setQuality(s.fxq);
    if (H.refreshMeters) H.refreshMeters();
  };
  H.resetSettings = function () { H.settings = Object.assign({}, DEF); H.saveSettings(); H.applySettings(); };
})();
