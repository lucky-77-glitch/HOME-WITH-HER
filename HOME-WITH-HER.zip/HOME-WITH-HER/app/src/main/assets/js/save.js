(function () {
  const H = window.HWH;
  const VER = 1;
  const MKEY = 'hwh.meta.v1';
  const mem = {};

  function rd(k) { try { return localStorage.getItem(k); } catch (e) { return mem[k] || null; } }
  function wr(k, v) { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } }
  function rm(k) { try { localStorage.removeItem(k); } catch (e) { delete mem[k]; } }

  // ----- meta: ending terbuka, chapter terbuka, teks terbaca, karakter terlihat -----
  function loadMeta() {
    const base = { v: VER, endings: {}, chapters: {}, seen: {}, chars: {} };
    try {
      const o = JSON.parse(rd(MKEY));
      if (o && typeof o === 'object') {
        return { v: VER, endings: o.endings || {}, chapters: o.chapters || {}, seen: o.seen || {}, chars: o.chars || {} };
      }
    } catch (e) { /* data rusak: mulai baru tanpa menghapus save */ }
    return base;
  }
  H.meta = loadMeta();
  H.saveMeta = function () { wr(MKEY, JSON.stringify(H.meta)); };

  // ----- slot -----
  const slotKey = (s) => 'hwh.save.' + s; // 1,2,3,'auto'
  H.slots = ['auto', 1, 2, 3];

  H.makeSave = function () {
    const S = H.S, sc = H.story[S.scene] || {};
    const ch = H.chapterOf(S.scene);
    return { v: VER, t: Date.now(), scene: S.scene, step: S.step, ch: S.ch,
      chTitle: ch ? ch.title : '', summary: (sc.sum || '') , name: S.name,
      aff: S.aff, sus: S.sus, ins: S.ins, f: S.f, clues: S.clues,
      picks: S.picks.slice(-80), log: S.log.slice(-60), ap: S.applied ? 1 : 0 };
  };

  H.validateSave = function (o) {
    if (!o || typeof o !== 'object') return 'Data kosong atau rusak.';
    if (o.v !== VER) return 'Versi save tidak dikenal (v' + o.v + ').';
    if (typeof o.scene !== 'string' || !H.story[o.scene]) return 'Adegan "' + o.scene + '" tidak ditemukan.';
    if (!Number.isInteger(o.step) || o.step < 0) return 'Posisi dialog tidak valid.';
    for (const k of ['aff', 'sus', 'ins']) if (typeof o[k] !== 'number' || isNaN(o[k])) return 'Status ' + k + ' tidak valid.';
    if (!o.f || typeof o.f !== 'object' || !Array.isArray(o.clues)) return 'Flag/petunjuk tidak valid.';
    if (typeof o.name !== 'string') return 'Nama tidak valid.';
    return null;
  };

  H.writeSlot = function (slot) {
    if (!H.S) return false;
    wr(slotKey(slot), JSON.stringify(H.makeSave()));
    return true;
  };
  // Mengembalikan {data} | {empty:true} | {error:'...'}
  H.readSlot = function (slot) {
    const raw = rd(slotKey(slot));
    if (!raw) return { empty: true };
    let o;
    try { o = JSON.parse(raw); } catch (e) { return { error: 'Data save rusak (bukan JSON valid).' }; }
    const err = H.validateSave(o);
    return err ? { error: err } : { data: o };
  };
  H.deleteSlot = function (slot) { rm(slotKey(slot)); };
  H.autosave = function () { if (H.S) H.writeSlot('auto'); };
  H.hasAnySave = function () { return H.slots.some((s) => !!H.readSlot(s).data); };
  H.latestSave = function () {
    let best = null;
    H.slots.forEach((s) => { const r = H.readSlot(s); if (r.data && (!best || r.data.t > best.t)) best = r.data; });
    return best;
  };
  H.stateFromSave = function (o) {
    return { v: 1, scene: o.scene, step: o.step, ch: o.ch, aff: H.CLAMP(o.aff), sus: H.CLAMP(o.sus), ins: H.CLAMP(o.ins),
      f: o.f, clues: o.clues.filter((c) => H.clues[c]), name: o.name, log: o.log || [], picks: o.picks || [], applied: !!o.ap };
  };
  H.fmtTime = (t) => { const d = new Date(t); const p = (n) => String(n).padStart(2, '0');
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()); };

  H.unlockEnding = function (id) { H.meta.endings[id] = Date.now(); H.saveMeta(); };
  H.unlockChapter = function (chId, snap) {
    if (!H.meta.chapters[chId]) { H.meta.chapters[chId] = snap; H.saveMeta(); }
  };
  H.wipeAll = function () {
    ['auto', 1, 2, 3].forEach((s) => rm(slotKey(s)));
    rm(MKEY); H.meta = loadMeta();
  };
})();
